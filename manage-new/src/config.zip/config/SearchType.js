const SEARCH_TYPE = {
  // 年龄段
  AGE: [
    {name: '小学', value: 1},
    {name: '初中', value: 2},
    {name: '高中', value: 3}
  ],
  AGE_ALL: [
    {name: '不限', value: ''},
    {name: '小学', value: 1},
    {name: '初中', value: 2},
    {name: '高中', value: 3}
  ],
  FORMAT: [
    {name: '5人制', value: 5},
    {name: '7人制', value: 7},
    {name: '8人制', value: 8},
    {name: '11人制', value: 11}
  ],
  FORMAT_ALL: [
    {name: '不限', value: ''},
    {name: '5人制', value: 5},
    {name: '7人制', value: 7},
    {name: '8人制', value: 8},
    {name: '11人制', value: 11}
  ],
  // 队伍类型
  TEAM_TYPE_ALL: [
    {name: '不限', value: 0},
    {name: '男', value: 1},
    {name: '女', value: 2},
    {name: '男女混合', value: 3}
  ],
  TEAM_TYPE: [
    {name: '男', value: 1},
    {name: '女', value: 2},
    {name: '男女混合', value: 3}
  ],
  // 性别
  SEX: [
    {name: '男', value: 0},
    {name: '女', value: 1}
  ],
  SEX_ALL: [
    {name: '男', value: 0},
    {name: '女', value: 1}
  ],
  // 联赛类型
  LEAGUE: [
    {name: '市长杯', value: 9},
    {name: '市长杯', value: 2},
    {name: '区长杯', value: 3},
    {name: '校长杯', value: 4},
    {name: '其他', value: 1}
  ],
  // 队员的位置
  LOCATION: [
    {name: '守门员', value: 'GK'},
    // {name: '左边后卫', value: 'lwb'},
    // {name: '左后卫', value: 'lb'},
    // {name: '左中后卫', value: 'lcb'},
    // {name: '中后卫', value: 'cb'},
    // {name: '右边后卫', value: 'rwb'},
    // {name: '右后卫', value: 'rb'},
    // {name: '右中后卫', value: 'rcb'},
    // {name: '攻击型后卫', value: 'ab'},
    // {name: '后腰', value: 'cdm'},
    // {name: '左后腰', value: 'lcdm'},
    // {name: '右后腰', value: 'rcdm'},
    // {name: '左边中场', value: 'lwm'},
    // {name: '左中场', value: 'lm'},
    // {name: '左中中场', value: 'lcm'},
    // {name: '中中场', value: 'cm'},
    // {name: '右边中场', value: 'rwm'},
    // {name: '右中场', value: 'rm'},
    // {name: '右中中场', value: 'rcm'},
    // {name: '前腰', value: 'cam'},
    // {name: '左前腰', value: 'lcam'},
    // {name: '右前腰', value: 'rcam'},
    // {name: '左前锋', value: 'lf'},
    {name: '中场', value: 'CF'},
    // {name: '右前锋', value: 'rf'},
    // {name: '左中锋', value: 'ls'},
    // {name: '中锋', value: 'st'},
    // {name: '右中锋', value: 'rs'},
    {name: '前锋', value: 'ST'},
    {name: '后卫', value: 'WB'}
  ],
  // 队员身体状况
  // 1受伤、2恢复期、0正常
  STATE: [
    {name: '正常', value: 1},
    {name: '伤病', value: 2},
    {name: '恢复', value: 3}
  ],
  // 队员常用脚
  FOOT: [
    {name: '左脚', value: 1},
    {name: '右脚', value: 2}
  ],
  PRO_ROLE: [
    {name: '不限', value: ''},
    {name: '管理者', value: 1},
    {name: '运维者', value: 2},
    {name: '教练', value: 3},
    {name: '队医', value: 4},
    {name: '科研', value: 5},
    {name: '技术分析', value: 6},
    {name: '球员', value: 7}
  ],
  // 教师等级
  TEACHER_LEVEL: [
    {name: '小学教师资格', value: 1},
    {name: '初级中学教师资格', value: 2},
    {name: '高级中学教师资格', value: 3},
    {name: '中等职业学校教师资格', value: 4},
    {name: '中等职业学校实习指导教师资格', value: 5},
    {name: '高等学校教师资格', value: 6},
    {name: '其他', value: 99}
  ],
  // 教练等级
  COACH_LEVEL: [
    {name: 'A级', value: 1},
    {name: 'B级', value: 2},
    {name: 'C级', value: 3},
    {name: 'D级', value: 4},
    {name: 'PRO', value: 5},
    {name: '其他', value: 99}
  ],
  // 指导员等级
  INSTRUCTOR_LEVEL: [
    {name: '教师', value: 1},
    {name: '教练', value: 2},
    {name: '教师和教练', value: 3},
    {name: '其他', value: 99}
  ],
  // 比赛类型
  MATCH_TYPE: [
    '其他', '省长杯', '市长杯', '区长杯', '校长杯'
  ],
  TEST_AGE_LIST: [
    {name: '不限', value: -1},
    {name: '小学一、二年级', value: 0},
    {name: '小学三、四年级', value: 1},
    {name: '小学五、六年级', value: 2},
    {name: '初中', value: 3},
    {name: '高中', value: 4}
  ]
}
export default SEARCH_TYPE
