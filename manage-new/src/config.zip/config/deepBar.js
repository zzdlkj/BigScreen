const DEEP_BAR = {
  DEEP_ONE: {
    tooltip: {
      show: true,
      trigger: 'item',
      formatter: '{c}'
    },
    grid: {
      left: '2%',
      top: 20,
      // right: '5%',
      bottom: 70,
      // height: '90%',
      // width: '80%',
      containLabel: true
    },
    xAxis: [
      {
        offset: 8,
        type: 'category',
        axisLine: {
          type: 'solid',
          color: '#28316d',
          width: '1'
        },
        axisLabel: {
          rotate: 25,
          interval: 0,
          show: true,
          splitNumber: 15,
          textStyle: {
            // align: 'center',
            fontSize: 18
          }
        },
        data: []
      }
    ],
    yAxis: [
      {
        type: 'value',
        name: '',
        splitLine: {
          show: false,
          lineStyle: {
            color: '#328316d'
          }
        },
        axisLabel: {
          interval: 0,
          rotate: 0,
          show: true,
          splitNumber: 30,
          textStyle: {
            fontSize: 18
          }
        }
      }
    ],
    series: [
      {
        name: '',
        type: 'bar',
        barMaxWidth: 30,
        label: {
          normal: {
            show: true,
            position: 'top',
            textStyle: {
              color: '#000000',
              fontSize: 14
            }
          }
        },
        data: [],
        itemStyle: {
          normal: {
            color: '#da5232'
            // colorList: [],
            // color: function (params) {
            //   var colorList = ['#da5232', '#595959', '#595959', '#595959', '#ffc000', '#ffc000']
            //   console.log(colorList[params.dataIndex])
            //   return colorList[params.dataIndex]
            // }
          }
        }
      }
    ]
  },
  DEEP_COMPARE: {
    legend: {
      orient: 'horizontal',
      y: 'bottom',
      x: 'center',
      itemWidth: 12,
      itemHeight: 12,
      data: ['跑动距离（m）', '对比项最高值'],
      textStyle: {    // 图例文字的样式
        fontSize: 16
      }
    },
    tooltip: {
      show: true,
      trigger: 'item',
      formatter: '{c}'
    },
    grid: {
      left: '2%',
      // right: '5%',
      bottom: 115,
      // height: '90%',
      top: 30,
      // width: '80%',
      containLabel: true
    },
    xAxis: [
      {
        offset: 8,
        type: 'category',
        axisLine: {
          type: 'solid',
          color: '#28316d',
          width: '1'
        },
        axisLabel: {
          rotate: 40,
          interval: 0,
          show: true,
          // splitNumber: 15,
          textStyle: {
            // align: 'center',
            fontSize: 17
          }
        },
        data: []
      }
    ],
    yAxis: [
      {
        type: 'value',
        name: '',
        splitLine: {
          show: false,
          lineStyle: {
            color: '#328316d'
          }
        },
        axisLabel: {
          interval: 0,
          rotate: 0,
          show: true,
          splitNumber: 30,
          textStyle: {
            fontSize: 16
          }
        }
      }
    ],
    series: [
      {
        name: '跑动距离（m）',
        type: 'bar',
        barMaxWidth: 30,
        barGap: 0,
        label: {
          normal: {
            show: true,
            position: 'top',
            textStyle: {
              color: '#000000',
              fontSize: 14
            }
          }
        },
        data: [],
        itemStyle: {
          normal: {
            color: '#da5232'
          }
        }
      },
      {
        name: '对比项最高值',
        type: 'bar',
        barMaxWidth: 30,
        label: {
          normal: {
            show: true,
            position: 'top',
            textStyle: {
              color: '#000000',
              fontSize: 14
            }
          }
        },
        data: [],
        itemStyle: {
          normal: {
            color: '#595959'
          }
        }
      }
    ]
  },
  GROUND_RUN: {
    tooltip: {
      show: true,
      trigger: 'item',
      formatter: '{c}'
    },
    grid: {
      // left: '2%',
      top: 20,
      bottom: 2
      // containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        show: false
      }
    ],
    color: ['#db3731', '#444'],
    yAxis: {
      type: 'value',
      name: '',
      max: 500,
      show: false
    },
    series: [
      {
        name: '',
        type: 'bar',
        barGap: 2,
        barMaxWidth: 50,
        label: {
          normal: {
            show: true,
            position: 'top',
            textStyle: {
              color: '#000000',
              fontSize: 14
            }
          }
        },
        data: [132]
      },
      {
        name: '',
        type: 'bar',
        barMaxWidth: 50,
        label: {
          normal: {
            show: true,
            position: 'top',
            textStyle: {
              color: '#000000',
              fontSize: 14
            }
          }
        },
        data: [154]
      }
    ]
  },
  DIFFER_PERCENT: {
    tooltip: {
      show: true,
      trigger: 'item',
      formatter: '{c}'
    },
    grid: {
      left: '2%',
      top: 5,
      bottom: 20,
      containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        axisLine: {
          type: 'solid',
          color: '#28316d',
          width: '1'
        },
        position: 'top',
        axisLabel: {
        //   rotate: 25,
          interval: 0,
          show: true,
          splitNumber: 15,
          // padding: [0, 0, 50, 0],
          textStyle: {
            // align: 'center',
            fontSize: 18
          }
        },
        data: []
      }
    ],
    yAxis: [
      {
        type: 'value',
        name: '%',
        max: 150,
        splitLine: {
          show: false,
          lineStyle: {
            color: '#328316d'
          }
        },
        axisLabel: {
          interval: 0,
          rotate: 0,
          show: true,
          splitNumber: 30,
          textStyle: {
            fontSize: 18
          }
        }
      }
    ],
    series: [
      {
        name: '',
        type: 'bar',
        barMaxWidth: 30,
        label: {
          normal: {
            show: true,
            position: 'top',
            textStyle: {
              color: '#000000',
              fontSize: 14
            }
          }
        },
        data: [],
        itemStyle: {
          normal: {
            color: '#da5232'
          }
        }
      }
    ]
  },
  ATTRACT_ECHARTS: {
    color: ['#db3731', '#444'],
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    grid: {
      left: 10,
      right: '4%',
      bottom: 20,
      top: 30,
      containLabel: true
    },
    xAxis: {
      type: 'value',
      show: false,
      boundaryGap: [0, 0.01],
      min: 0,
      max: 4000,
      interval: 20,
      axisLabel: {
        formatter: '{value}%',
        textStyle: {
          fontWeight: '80'
        }
      }
    },
    yAxis: {
      type: 'category',
      data: ['右\n路\n跑\n动', '中\n路\n跑\n动', '左\n路\n跑\n动'],
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        interval: 0,
        rotate: 0,
        margin: 10,
        inside: false,
        textStyle: {
          fontWeight: '50',
          fontSize: 16
        }
      }
    },
    series: [
      {
        type: 'bar',
        label: {
          normal: {
            show: true,
            position: 'right'
          }
        },
        barGap: 0,
        data: [1965, 3414, 2000]
      },
      {
        type: 'bar',
        label: {
          normal: {
            show: true,
            position: 'right'
          }
        },
        data: [965, 2414, 1500]
      }
    ]
  },
  DEFENCE_ECHARTS: {
    grid: [
      {
        show: false,
        left: -10,
        right: 20,
        bottom: 20,
        top: 30,
        containLabel: true,
        width: '100%'
      },
      {
        width: '0%'
      }
    ],
    xAxis: [
      {
        type: 'value',
        max: 500,
        inverse: true,
        show: false
      },
      {
        gridIndex: 1,
        type: 'value',
        axisLine: {
          show: false
        },
        axisTick: {
          show: false
        },
        position: 'bottom',
        axisLabel: {
          show: true,
          textStyle: {
            color: '#B2B2B2',
            fontSize: 12
          }
        },
        splitLine: {
          show: false
        }
      }
    ],
    yAxis: [
      {
        type: 'category',
        inverse: true,
        position: 'right',
        data: ['左\n路\n跑\n动', '中\n路\n跑\n动', '右\n路\n跑\n动'],
        axisTick: {
          show: false
        },
        axisLabel: {
          textStyle: {
            fontSize: 16
          }
        }
      },
      {
        gridIndex: 1,
        type: 'category',
        show: false,
        inverse: true,
        position: 'right',
        data: ['左路跑动', '中路跑动', '右路跑动']
      }
    ],
    color: ['#db3731', '#444'],
    series: [
      {
        name: '目录',
        type: 'bar',
        barGap: 0,
        label: {
          normal: {
            show: true,
            position: 'left'
          }
        },
        data: [389, 259, 262]
      },
      {
        name: '牡蛎',
        type: 'bar',
        barGap: 0,
        label: {
          normal: {
            show: true,
            position: 'left'
          }
        },
        data: [389, 259, 262]
      }
    ]
  },
  SPEED56_TREND: {
    tooltip: {
      show: true,
      trigger: 'item',
      formatter: '{c}'
    },
    grid: {
      left: '2%',
      top: 25,
      bottom: 20,
      containLabel: true
    },
    color: ['#db3731', '#444'],
    xAxis: [
      {
        type: 'category',
        axisLine: {
          type: 'solid',
          color: '#28316d',
          width: '1'
        },
        axisLabel: {
          interval: 0,
          show: true,
          // splitNumber: 15,
          textStyle: {
            fontSize: 18
          }
        },
        data: []
      }
    ],
    yAxis: [
      {
        type: 'value',
        name: '次',
        // max: 100,
        splitLine: {
          show: false,
          lineStyle: {
            color: '#328316d'
          }
        },
        axisLabel: {
          interval: 0,
          rotate: 0,
          show: true,
          splitNumber: 30,
          textStyle: {
            fontSize: 18
          }
        }
      }
    ],
    series: [
      {
        name: '',
        type: 'line',
        label: {
          normal: {
            show: true,
            position: 'top',
            textStyle: {
              color: '#000000',
              fontSize: 14
            }
          }
        },
        data: []
      },
      {
        name: '',
        type: 'line',
        label: {
          normal: {
            show: true,
            position: 'top',
            textStyle: {
              color: '#000000',
              fontSize: 14
            }
          }
        },
        data: []
      }
    ]
  }
}

export default {DEEP_BAR}
