/* eslint-disable */
const LEVEL = {
  // let cc = CLASS_ROM
  CLASS_ROM: {
    color: ['#5d9cec', '#62c87f', '#f15755', '#fc863f'],
    legend: {
      orient: 'vertical',
      y: 'bottom',
      icon: 'circle',
      padding: [0, 0, 30, 0],
      itemWidth: 30,
      data: ['幼儿园', '小学', '初中', '高中'],
      formatter: function (name) {
      	let oa = LEVEL.CLASS_ROM.series[0].data
      	let num = oa[0].value + oa[1].value + oa[2].value + oa[3].value
      	for (let i = 0; i < LEVEL.CLASS_ROM.series[0].data.length; i++) {
          	if (name==oa[i].name) {
	          	return name + ' ' + oa[i].value + ' ' + (oa[i].value/num * 100).toFixed(2) + '%'
	        }
      	}
      }
    },
    textStyle: {
      fontSize: 16,
      textBorderWidth : 60
    },
    tooltip: {
      trigger: 'item',
      formatter: '{a} <br/>{b} : {c} ({d}%)'
    },
    series: [{
      name: '年级分段',
      type: 'pie',
      radius : '60%',
      center: ['50%', '30%'],
      data: [
        {value:5, name:'幼儿园'},
        {value:2, name:'小学'},
        {value:2, name:'初中'},
        {value:1, name:'高中'},
      ],
      itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
      },
      itemStyle: {
        normal: {
          label: { 
              show: false, 
              formatter: '{b}: {c} ({d}%)' 
            }
          },
        labelLine: {show:true}
      }
    }
	  ]
  }
}
export default LEVEL