/**
 * Created by dongshuyue on 2016/10/28.
 */
const HOME = {
  PRO_VIEW_ECHARTS: {
    legend: {
      data: [],
      selected: {}
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      },
      formatter: function (params) {
        let len = params.length - 3
        let arrDj = params.splice(0, len)
        let str = `${arrDj[0].name}<br><span style='display:inline-block;background:${arrDj[0].color};width:8px;height:8px;border-radius:50%;vertical-align:baseline;margin-right:5px;'></span> ${arrDj[0].seriesName}(${arrDj.length})次`
        let num = 0
        arrDj.forEach(k => {
          num += k.value
        })
        str = str + ' ' + num + '<br>'

        params.forEach(k => {
          str = `${str}<span style='display:inline-block;background:${k.color};width:8px;height:8px;border-radius:50%;vertical-align:baseline;margin-right:5px;'></span> ${k.seriesName} ${k.value}<br>`
        })
        return str
      }
    },
    color: ['#2f4554', '#619fa7', '#91c7ae', '#c33430'],
    grid: {
      left: '4%',
      right: '5%',
      bottom: '20%'
    },
    xAxis: {
      type: 'category',
      axisLabel: {
        rotate: 45,
        interval: 0
      },
      data: []
    },
    yAxis: [
      {
        min: 0,
        name: '距离(km)',
        splitLine: {
          show: false
        }
      },
      {
        min: 0,
        max: 100,
        name: '百分比(%)',
        splitLine: {
          show: false
        }
      }
    ],
    series: []
  },
  VIEW_ECHARTS: {
    legend: {
      data: ['小学人数', '初中人数', '高中人数', '监测次数']
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    color: ['#2f4554', '#619fa7', '#91c7ae', '#c33430'],
    grid: {
      left: '4%',
      right: '5%',
      bottom: '20%'
    },
    xAxis: {
      type: 'category',
      axisLabel: {
        rotate: 45,
        interval: 0
      },
      data: []
    },
    yAxis: [
      {
        min: 0,
        name: '人数',
        splitLine: {
          show: false
        }
      },
      {
        min: 0,
        name: '次数',
        splitLine: {
          show: false
        }
      }
    ],
    series: [
      {
        name: '小学人数',
        type: 'bar',
        barMaxWidth: 40,
        stack: '人数',
        data: []
      },
      {
        name: '初中人数',
        type: 'bar',
        barMaxWidth: 40,
        stack: '人数',
        data: []
      },
      {
        name: '高中人数',
        type: 'bar',
        barMaxWidth: 40,
        stack: '人数',
        data: []
      },
      {
        name: '监测次数',
        type: 'line',
        symbolSize: 8,
        yAxisIndex: 1,
        data: []
      }
    ]
  },
  AREA_VIEW_ECHARTS: {
    legend: {
      data: ['监测人数', '监测次数']
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    color: ['#2f4554', '#c33430'],
    grid: {
      left: '4%',
      right: '5%',
      bottom: '20%'
    },
    xAxis: {
      type: 'category',
      axisLabel: {
        rotate: 45,
        interval: 0,
        formatter: function (params) {
          if (!params) return ''
          var newParamsName = ''
          var paramsNameNumber = params.length
          var provideNumber = 8
          var rowNumber = Math.ceil(paramsNameNumber / provideNumber)
          if (paramsNameNumber > provideNumber) {
            for (var p = 0; p < rowNumber; p++) {
              var tempStr = ''
              var start = p * provideNumber
              var end = start + provideNumber
              if (p === rowNumber - 1) {
                tempStr = params.substring(start, paramsNameNumber)
              } else {
                tempStr = params.substring(start, end) + '\n'
              }
              newParamsName += tempStr
            }
          } else {
            newParamsName = params
          }
          return newParamsName
        }
      },
      data: []
    },
    yAxis: [
      {
        min: 0,
        name: '人数',
        splitLine: {
          show: false
        }
      },
      {
        min: 0,
        name: '次数',
        splitLine: {
          show: false
        }
      }
    ],
    series: [
      {
        name: '监测人数',
        type: 'bar',
        barMaxWidth: 40,
        stack: '人数',
        data: []
      },
      {
        name: '监测次数',
        type: 'line',
        symbolSize: 8,
        yAxisIndex: 1,
        data: []
      }
    ]
  },
  GROW_ECHARTS: {
    legend: {
      data: ['监测增长次数']
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      },
      formatter: function (params) {
        var tar = ''
        if (params[1].value !== '-') {
          tar = params[1]
        } else {
          tar = params[0]
        }
        var sum = params[0].value + tar.value
        return '总监测次数：' + sum + '</br>' + tar.name + ' ' + tar.seriesName + ' : ' + tar.value
      }
    },
    color: ['#c33430'],
    barGap: '4%',
    xAxis: {
      data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
      splitLine: {
        show: false
      }
    },
    grid: {
      left: '6%',
      right: '6%'
    },
    yAxis: {
      type: 'value',
      min: 0,
      name: '次数',
      splitLine: {
        show: false
      }
    },
    series: [
      {
        name: '辅助',
        type: 'bar',
        stack: '总量',
        barWidth: '26',
        itemStyle: {
          normal: {
            barBorderColor: 'rgba(255,0,0,1)',
            borderType: 'dashed',
            color: 'transparent'
          },
          emphasis: {
            barBorderColor: 'rgba(255,0,0,1)',
            borderType: 'dashed',
            color: 'transparent'
          }
        },
        data: (function () {
          var data = []
          var arr = [0]
          for (var i = 1; i < data.length; i++) {
            arr[i] = arr[i - 1] + data[i - 1]
          }
          return arr
        })()
      },
      {
        name: '监测增长次数',
        type: 'bar',
        barWidth: '30',
        stack: '总量',
        data: []
      }
    ]
  },
  MONITOR_SCH: {
    legend: {
      x: 'center',
      y: 'bottom'
         // data: ['rose1', 'rose2', 'rose3']
    },
    // color: ['#91c7ae', '#c23531', '#d48265'],
    calculable: true,
    series: [
      {
        name: '面积模式',
        type: 'pie',
        radius: [20, 80],
        center: ['50%', '50%'],
        roseType: 'area',
        data: []
      }
    ]
  },
  ITEM_DATAS: {
    color: ['#fad71f', '#d3696a', '#82c2e0', '#e38980', '#f7db88'],
    tooltip: {
      show: false
         // formatter: '{a} <br/>{b} : {c} 场次({d}%)'
    },
    legend: {
         // itemGap: 12,
         // data: ['比赛', '训练', '测评']
    },
    series: [
      {
        name: '比赛',
        type: 'pie',
        radius: ['75%', '60%'],
        itemStyle: {
          normal: {
            label: {show: false},
            labelLine: {show: false}
          }
        },
        hoverAnimation: false,
        data: [
          {
            value: 0,
            name: '比赛'
          },
          {
            value: 0,
            name: 'invisible',
            tooltip: {
              show: false
            },
            itemStyle: {
              normal: {
                color: '#f1f1f1',
                label: {show: false},
                labelLine: {show: false}
              },
              emphasis: {
                color: '#f1f1f1'
              }
            }
          }
        ]
      },
      {
        name: '训练',
        type: 'pie',
        // clockWise:false,
        radius: ['57%', '42%'],
        itemStyle: {
          normal: {
            label: {show: false},
            labelLine: {show: false}
          }
        },
        hoverAnimation: false,
        data: [
          {
            value: 0,
            name: '训练'
          },
          {
            value: 0,
            name: 'invisible',
            itemStyle: {
              normal: {
                color: '#f1f1f1',
                label: {show: false},
                labelLine: {show: false}
              },
              emphasis: {
                color: '#f1f1f1'
              }
            }
          }
        ]
      },
      {
        name: '测评',
        type: 'pie',
        // clockWise:false,
        hoverAnimation: false,
        radius: ['39%', '24%'],
        itemStyle: {
          normal: {
            label: {show: false},
            labelLine: {show: false}
          }
        },
        data: [
          {
            value: 0,
            name: '测评'
          },
          {
            value: 0,
            name: 'invisible',
            itemStyle: {
              normal: {
                color: '#f1f1f1',
                label: {show: false},
                labelLine: {show: false}
              },
              emphasis: {
                color: '#f1f1f1'
              }
            }
          }
        ]
      }
    ]
  },
  SCHOOL_VIEW: {
    legend: {
      data: ['监测人数', '监测次数']
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    color: ['#2f4554', '#c33430'],
    grid: {
      left: '4%',
      right: '5%',
      bottom: '20%'
    },
    xAxis: {
      type: 'category',
      axisLabel: {
        rotate: 0,
        interval: 0
      },
      data: ['一年级', '二年级', '三年级', '四年级', '五年级', '六年级']
    },
    yAxis: [
      {
        min: 0,
        name: '人数',
        splitLine: {
          show: false
        }
      },
      {
        min: 0,
        name: '次数',
        splitLine: {
          show: false
        }
      }
    ],
    series: [
      {
        name: '监测人数',
        type: 'bar',
        barMaxWidth: 40,
        data: [10, 20, 25, 30, 20, 26]
      },
      {
        name: '监测次数',
        type: 'line',
        symbolSize: 8,
        yAxisIndex: 1,
        data: [10, 20, 25, 30, 20, 26]
      }
    ]
  },
  PRO: {
    TRAIN_VIEW_ECHARTS: {
      legend: {
        data: ['累计人均训练量', '单次人均训练量', '平均训练高强度跑占比', '平均训练心率负荷强度']
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        formatter: function (params) {
          let len = params.length - 3
          let arrDj = params.splice(0, len)
          let str = `${arrDj[0].name}<br><span style='display:inline-block;background:${arrDj[0].color};width:8px;height:8px;border-radius:50%;vertical-align:baseline;margin-right:5px;'></span> ${arrDj[0].seriesName}`
          let num = 0
          arrDj.forEach(k => {
            num += k.value
          })
          str = str + num + '<br>'

          params.forEach(k => {
            str = `${str}<span style='display:inline-block;background:${k.color};width:8px;height:8px;border-radius:50%;vertical-align:baseline;margin-right:5px;'></span> ${k.seriesName} ${k.value}<br>`
          })
          console.log(params)
          return str
        }
      },
      color: ['#3f4658', '#61a0a8', '#93b963', '#f9c20d'],
      grid: {
        left: '4%',
        right: '5%',
        bottom: '20%'
      },
      xAxis: {
        type: 'category',
        axisLabel: {
          // rotate: 45,
          interval: 0
        },
        data: ['队伍一', '队伍二']
      },
      yAxis: [
        {
          min: 0,
          name: '距离(km)',
          splitLine: {
            show: false
          }
        },
        {
          min: 0,
          name: '占比(%)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '累计人均训练量',
          type: 'bar',
          stack: '累计人均训练量',
          barMaxWidth: 40,
          barGap: 0,
          data: [1, 2]
        },
        {
          name: '累计人均训练量',
          type: 'bar',
          stack: '累计人均训练量',
          barMaxWidth: 40,
          barGap: 0,
          data: [1, 2]
        },
        {
          name: '累计人均训练量',
          type: 'bar',
          stack: '累计人均训练量',
          barMaxWidth: 40,
          barGap: 0,
          data: [1, 2]
        },
        {
          name: '单次人均训练量',
          type: 'bar',
          barMaxWidth: 40,
          barGap: 0,
          data: [1, 2.2]
        },
        {
          name: '平均训练高强度跑占比',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: [8, 12]
        },
        {
          name: '平均训练心率负荷强度',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: [100, 150]
        }
      ]
    },
    MATCH_VIEW_ECHARTS: {
      legend: {
        data: ['累计人均比赛量', '单次人均比赛量', '平均比赛高强度跑占比', '平均比赛心率负荷强度']
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        formatter: function (params) {
          let len = params.length - 3
          let arrDj = params.splice(0, len)
          let str = `${arrDj[0].name}<br><span style='display:inline-block;background:${arrDj[0].color};width:8px;height:8px;border-radius:50%;vertical-align:baseline;margin-right:5px;'></span> ${arrDj[0].seriesName}`
          let num = 0
          arrDj.forEach(k => {
            num += k.value
          })
          str = str + num + '<br>'

          params.forEach(k => {
            str = `${str}<span style='display:inline-block;background:${k.color};width:8px;height:8px;border-radius:50%;vertical-align:baseline;margin-right:5px;'></span> ${k.seriesName} ${k.value}<br>`
          })
          console.log(params)
          return str
        }
      },
      color: ['#3f4658', '#61a0a8', '#93b963', '#f9c20d'],
      grid: {
        left: '4%',
        right: '5%',
        bottom: '20%'
      },
      xAxis: {
        type: 'category',
        axisLabel: {
          // rotate: 45,
          interval: 0
        },
        data: ['队伍一', '队伍二']
      },
      yAxis: [
        {
          min: 0,
          name: '距离(km)',
          splitLine: {
            show: false
          }
        },
        {
          min: 0,
          name: '占比(%)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '累计人均比赛量',
          type: 'bar',
          stack: '累计人均比赛量',
          barMaxWidth: 40,
          barGap: 0,
          data: [1, 2]
        },
        {
          name: '累计人均比赛量',
          type: 'bar',
          stack: '累计人均比赛量',
          barMaxWidth: 40,
          barGap: 0,
          data: [1, 2]
        },
        {
          name: '累计人均比赛量',
          type: 'bar',
          stack: '累计人均比赛量',
          barMaxWidth: 40,
          barGap: 0,
          data: [1, 2]
        },
        {
          name: '单次人均比赛量',
          type: 'bar',
          barMaxWidth: 40,
          barGap: 0,
          data: [1, 2.2]
        },
        {
          name: '平均比赛高强度跑占比',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: [8, 12]
        },
        {
          name: '平均比赛心率负荷强度',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: [100, 150]
        }
      ]
    },
    PERFOM_LOAD_ECHARTS: {
      legend: {
        data: ['全队平均', '全队最高']
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#67A0A7', '#DF3137', '#D28971'],
      barGap: '4%',
      grid: {
        left: '5%',
        right: '5%',
        bottom: '20%'
      },
      xAxis: {
        type: 'category',
        axisLabel: {
          // rotate: 45,
          interval: 0
        },
        data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
      },
      yAxis: [
        {
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        }
      ],
      dataZoom: [
        {
          type: 'slider',
          startValue: 0,
          endValue: 11
        }
      ],
      series: [
        {
          name: '全队平均',
          type: 'line',
          data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        },
        {
          name: '全队最高',
          type: 'line',
          data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        }
      ]
    },
    PERFOM_PLAY_ECHARTS: {
      legend: {
        data: ['冲刺跑次数', '全队平均', '全队最高']
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#67A0A7', '#DF3137', '#D28971'],
      barGap: '4%',
      grid: {
        left: '5%',
        right: '5%',
        bottom: '20%'
      },
      xAxis: {
        type: 'category',
        axisLabel: {
          // rotate: 45,
          interval: 0
        },
        data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
      },
      yAxis: [
        {
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        }
      ],
      dataZoom: [
        {
          type: 'slider',
          startValue: 0,
          endValue: 11
        }
      ],
      series: [
        {
          name: '冲刺跑次数',
          type: 'bar',
          barMaxWidth: 40,
          data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        },
        {
          name: '全队平均',
          type: 'line',
          data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        },
        {
          name: '全队最高',
          type: 'line',
          data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        }
      ]
    }
  }
}

export default HOME
