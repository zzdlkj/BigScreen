const DEMOSCHOOLNAME = {
  TEACHER_NAME: [
    {
      name: '邱京巍',
      sex: 'male',
      src: 'http://www.sipg-fc.com/sipg/d/file/zhongwenban/qiudui/qiuduiu181/jiaolian11/2016-06-23/bb3d5e6117167ac3fde6328e25d101ba.jpg'
    },
    {
      name: '黄小军',
      sex: 'male',
      src: 'http://www.sipg-fc.com/sipg/d/file/zhongwenban/qiudui/qiuduiu181/jiaolian11/2016-06-23/51b5dcb538b2a532bf16078e27e7cc1a.jpg'
    },
    {
      name: '蔡惠强',
      sex: 'male',
      src: 'http://www.sipg-fc.com/sipg/d/file/zhongwenban/qiudui/qiuduiu181/jiaolian11/2016-07-05/27e8cda86ace568c0de3dc4845ac0e92.jpg'
    }
  ],
  COACH_NAME: [
    {
      name: '邓俊',
      sex: 'male'
    },
    {
      name: '王翔',
      sex: 'male'
    }
  ],
  STUDENT_NAME: [
    {
      name: '王芮琪',
      sex: 'male'
    },
    {
      name: '周萌',
      sex: 'male'
    },
    {
      name: '陈晨',
      sex: 'male'
    },
    {
      name: '张鹏',
      sex: 'male'
    },
    {
      name: '汤宗靓',
      sex: 'male'
    },
    {
      name: '朱煜辉',
      sex: 'male'
    },
    {
      name: '何涛',
      sex: 'male'
    },
    {
      name: '孙澜',
      sex: 'male'
    },
    {
      name: '陈轩',
      sex: 'male'
    },
    {
      name: '方楚河',
      sex: 'male'
    },
    {
      name: '陈金龙',
      sex: 'male'
    },
    {
      name: '苏长虹',
      sex: 'male'
    },
    {
      name: '常斌',
      sex: 'male'
    },
    {
      name: '刘森',
      sex: 'male'
    },
    {
      name: '钱梦洁',
      sex: 'female'
    },
    {
      name: '王丽',
      sex: 'female'
    },
    {
      name: '陈玉鹏',
      sex: 'male'
    },
    {
      name: '刘瑞峰',
      sex: 'female'
    },
    {
      name: '郭丽华',
      sex: 'female'
    },
    {
      name: '徐刘伟',
      sex: 'male'
    },
    {
      name: '顾勇岱',
      sex: 'male'
    },
    {
      name: '王子轩',
      sex: 'male'
    },
    {
      name: '刘飞',
      sex: 'male'
    },
    {
      name: '丁北洋',
      sex: 'male'
    },
    {
      name: '高晓雯',
      sex: 'female'
    },
    {
      name: '周萌',
      sex: 'female'
    },
    {
      name: '刘洋',
      sex: 'male'
    },
    {
      name: '薛凯',
      sex: 'male'
    },
    {
      name: '徐莹',
      sex: 'female'
    },
    {
      name: '袁绍祖',
      sex: 'male'
    }
  ]
}
export default DEMOSCHOOLNAME
