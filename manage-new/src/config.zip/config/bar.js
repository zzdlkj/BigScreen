const AREA = {
  legend: {
    data: []
  },
  tooltip: {
    trigger: 'axis',
    axisPointer: {
      type: 'shadow'
    }
  },
  color: ['#2f4554', '#619fa7', '#91c7ae'],
  grid: {
    left: '4%',
    right: '5%',
    bottom: '20%'
  },
  xAxis: {
    type: 'category',
    axisLabel: {
      rotate: 45,
      interval: 0
    },
    data: ['北京市', '河南省', '广州']
  },
  yAxis: [
    {
      min: 0,
      name: '人数',
      splitLine: {
        show: false
      }
    }
  ],
  series: []
}

export {AREA}
