/**
 * Created by dongshuyue on 2016/11/5.
 */
const TRAIN = {
  TEAM_TRAIN_REPORT: {
    HR_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        formatter: '{a}<br>{b} : {c} %'
      },
      grid: {
        left: '0%',
        right: '0%',
        bottom: '9%',
        containLabel: true
      },
      legend: {
        // data: ['全场平均'],
        top: '3%'
      },
      color: ['#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: ['[0-65%]', '[66%-71%]', '[72%-78%]', '[79%-85%]', '[86%-92%]', '[93%-100%]'].map(function (str) {
          return str.replace(' ', '\n\n')
        }),
        splitArea: {
          show: true,
          areaStyle: {
            color: ['#b2e0d1', '#fff5c1', '#ffe0c1', '#f0b7c5', '#d1b2e0', '#d8b2bd']
          }
        }
      },
      yAxis: [
        {
          type: 'value',
          max: 100,
          min: 0,
          name: '占比',
          splitLine: {
            show: false
          },
          axisLabel: {
            formatter: '{value}%'
          }
        }
      ],
      series: [
        {
          name: '全场平均',
          type: 'bar',
          barMaxWidth: 40,
          data: [10, 20, 20, 30, 20, 10]
        }
      ]
    },
    SP_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        formatter: '{a}<br>{b} : {c} %'
      },
      grid: {
        left: '2%',
        right: '2%',
        bottom: '3%',
        containLabel: true
      },
      legend: {
        // data: ['全场平均'],
        top: '3%'
      },
      color: ['#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: ['走慢跑 [0-1.6)', '低速跑 [1.6-2.5)', '中速跑 [2.5-3.5)', '快速跑 [3.5-4.5)', '高速跑 [4.5-5.3)', '冲刺跑 [5.3)'].map(function (str) {
          return str.replace(' ', '\n\n')
        }),
        splitArea: {
          show: true,
          areaStyle: {
            color: ['#b2e0d1', '#fff5c1', '#ffe0c1', '#f0b7c5', '#d1b2e0', '#d8b2bd']
          }
        }
      },
      yAxis: [
        {
          type: 'value',
          max: 100,
          min: 0,
          name: '占比',
          splitLine: {
            show: false
          },
          axisLabel: {
            formatter: '{value} %'
          }
        }
      ],
      series: [
        {
          name: '全场平均',
          type: 'bar',
          barMaxWidth: 40,
          data: [10, 20, 20, 30, 20, 10]
        }
      ]
    },
    DISTANCE_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      grid: {
        left: '4%',
        right: '5%',
        bottom: '35%'
      },
      legend: {
        data: ['跑动距离'],
        top: '3%'
      },
      color: ['#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          show: true,
          rotate: 45,
          interval: 0
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: [1000, 1200, 2200, 1700, 1900, 2100],
          markLine: {
            data: [
              {type: 'average', name: '全组平均值'}
            ]
          }
        }
      ]
    },
    LOAD_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      grid: {
        right: '1%',
        left: '5%'
      },
      legend: {
        // data: ['全场平均'],
        top: '3%'
      },
      color: ['#e93232', '#61a0a8', '#d48265'],
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          rotate: 45,
          interval: 0
        }
      },
      yAxis: [
        {
          type: 'value',
          // max: 250,
          min: 0,
          name: 'trimp',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '全场平均',
          type: 'line',
          symbolSize: 8,
          data: []
        }
      ]
    },
    BODY_LOAD_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        // data: ['全场平均'],
        top: '3%'
      },
      grid: {
        right: '1%',
        left: '5%'
      },
      color: ['#e93232', '#61a0a8', '#d48265'],
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          rotate: 45,
          interval: 0
        }
      },
      yAxis: [
        {
          type: 'value',
          max: 250,
          min: 0,
          name: '负荷',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '全场平均',
          type: 'line',
          symbolSize: 8,
          data: []
        }
      ]
    },
    SPRINT_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      grid: {
        left: '4%',
        right: '5%',
        bottom: '35%'
      },
      legend: {
        data: ['冲刺距离', '冲刺跑占比'],
        top: '3%'
      },
      color: ['#2f4554', '#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          show: true,
          rotate: 45,
          interval: 0
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        },
        {
          type: 'value',
          min: 0,
          max: 30,
          name: '占比',
          axisLabel: {
            formatter: '{value} %'
          },
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '冲刺距离',
          type: 'line',
          symbolSize: 8,
          data: [1000, 1200, 2200, 1700, 1900, 2100],
          markLine: {
            data: [
              {type: 'average', name: '全组平均值'}
            ],
            label: {
              normal: {
                show: false
              }
            }
          }
        },
        {
          name: '冲刺跑占比',
          type: 'bar',
          barMaxWidth: '40',
          data: [50, 30, 50, 40, 60, 20],
          yAxisIndex: 1,
          markLine: {
            data: [
              {type: 'average', name: '全组平均值'}
            ],
            label: {
              normal: {
                show: false
              }
            }
          }
        }
      ]
    },
    HIGH_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      grid: {
        left: '2%',
        right: '2%',
        bottom: '25%',
        containLabel: true
      },
      legend: {
        data: ['高速跑距离', '高速跑占比'],
        top: '3%'
      },
      color: ['#d48265', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          show: true,
          rotate: 45,
          interval: 0
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        },
        {
          type: 'value',
          min: 0,
          max: 30,
          name: '占比',
          axisLabel: {
            formatter: '{value} %'
          },
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '高速跑距离',
          type: 'line',
          symbolSize: 8,
          data: [1000, 1200, 2200, 1700, 1900, 2100],
          markLine: {
            data: [
              {type: 'average', name: '全组平均值'}
            ],
            label: {
              normal: {
                show: false
              }
            }
          }
        },
        {
          name: '高速跑占比',
          type: 'bar',
          barMaxWidth: '40',
          data: [50, 30, 50, 40, 60, 20],
          yAxisIndex: 1,
          markLine: {
            data: [
              {type: 'average', name: '全组平均值'}
            ],
            label: {
              normal: {
                show: false
              }
            }
          }
        }
      ]
    },
    AVG_SPEED_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['平均速度'],
        top: '3%'
      },
      color: ['#2b3c4a', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: ['张一', '张二', '张三', '张思', '张武', '张六']
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: 'm/s',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '平均速度',
          type: 'line',
          symbolSize: 8,
          data: [10, 20, 15, 17, 9, 12],
          markLine: {
            data: [
              {type: 'average', name: '全组平均值'}
            ]
          }
        }
      ]
    },
    HR_RECOVER_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['心率恢复速度'],
        top: '3%'
      },
      color: ['#2b3c4a', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: ['张一', '张二', '张三', '张思', '张武', '张六']
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: 'bpm/s',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '心率恢复速度',
          type: 'line',
          symbolSize: 8,
          data: [10, 20, 15, 17, 9, 12],
          markLine: {
            data: [
              {type: 'average', name: '全组平均值'}
            ]
          }
        }
      ]
    },
    HR_ADVANCE_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        formatter: function (params) {
          let str = params[0].name
          params.forEach(function (val) {
            str += '<br>' + val.seriesName + ' : ' + val.value + '%'
          })
          return str
        }
      },
      grid: {
        left: '4%',
        right: '5%',
        bottom: '25%'
      },
      legend: {
        data: ['[0-65%]', '[66%-71%]', '[72%-78%]', '[79%-85%]', '[86%-92%]', '[93%-100%]'],
        top: '3%'
      },
      color: ['#82cd71', '#add857', '#eed766', '#ec9e51', '#f06044', '#ce0f3f'],
      xAxis: {
        type: 'category',
        data: ['张一', '张二', '张三', '张思', '张武', '张六'],
        axisLabel: {
          rotate: 45,
          interval: 0
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          max: 100,
          name: '占比(%)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '[0-65%]',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: 60,
          data: [10, 20, 15, 17, 9, 12]
        },
        {
          name: '[66%-71%]',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: 60,
          data: [10, 20, 15, 17, 9, 12]
        },
        {
          name: '[72%-78%]',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: 60,
          data: [10, 20, 15, 17, 9, 12]
        },
        {
          name: '[79%-85%]',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: 60,
          data: [10, 20, 15, 17, 9, 12]
        },
        {
          name: '[86%-92%]',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: 60,
          data: [10, 10, 15, 17, 9, 12]
        },
        {
          name: '[93%-100%]',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: 60,
          data: [10, 10, 15, 10, 9, 12]
        }
      ]
    },
    SP_ADVANCE_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        formatter: function (params) {
          let str = params[0].name
          params.forEach(function (val) {
            str += '<br>' + val.seriesName + ' : ' + val.value + '%'
          })
          return str
        }
      },
      grid: {
        left: '4%',
        right: '5%',
        bottom: '25%'
      },
      legend: {
        data: ['走慢跑 [0-1.6)', '低速跑 [1.6-2.5)', '中速跑 [2.5-3.5)', '快速跑 [3.5-4.5)', '高速跑 [4.5-5.3)', '冲刺跑 [5.3)'],
        top: '3%'
      },
      color: ['#82cd71', '#add857', '#eed766', '#ec9e51', '#f06044', '#ce0f3f'],
      xAxis: {
        type: 'category',
        data: ['张一', '张二', '张三', '张思', '张武', '张六'],
        axisLabel: {
          rotate: 45,
          interval: 0
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          max: 100,
          name: '占比(%)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '走慢跑 [0-1.6)',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: 60,
          data: [10, 20, 15, 17, 9, 12]
        },
        {
          name: '低速跑 [1.6-2.5)',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: 60,
          data: [10, 20, 15, 17, 9, 12]
        },
        {
          name: '中速跑 [2.5-3.5)',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: 60,
          data: [10, 20, 15, 17, 9, 12]
        },
        {
          name: '快速跑 [3.5-4.5)',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: 60,
          data: [10, 20, 15, 17, 9, 12]
        },
        {
          name: '高速跑 [4.5-5.3)',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: 60,
          data: [10, 10, 15, 17, 9, 12]
        },
        {
          name: '冲刺跑 [5.3)',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: 60,
          data: [10, 10, 15, 10, 9, 12]
        }
      ]
    },
    LOAD_ADVANCE_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      grid: {
        left: '4%',
        right: '5%',
        bottom: '35%'
      },
      legend: {
        data: ['心率负荷', '身体负荷'],
        top: '3%'
      },
      color: ['#d48265', '#e93232', '#61a0a8'],
      xAxis: {
        type: 'category',
        data: ['5\'', '10\'', '15\'', '20\'', '25\'', '30\''],
        axisLabel: {
          rotate: 45,
          interval: 0
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: 'trimp',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        // {
        //   name: '跑动指数',
        //   type: 'bar',
        //   barMaxWidth: 40,
        //   data: [120, 210, 210, 150, 120, 230]
        // },
        {
          name: '心率负荷',
          type: 'line',
          symbolSize: 8,
          data: [150, 180, 200, 170, 190, 220]
        },
        {
          name: '身体负荷',
          type: 'line',
          symbolSize: 8,
          data: [120, 210, 210, 150, 120, 230]
        }
      ]
    }
  },
  PERSON_TRAIN_REPORT: {
    DISTANCE_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['跑动距离'],
        top: '3%'
      },
      color: ['#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: []
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: [],
          markLine: {
            data: [
              {type: 'average', name: '全组平均值'}
            ]
          }
        }
      ]
    },
    HIGH_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['高速跑距离'],
        top: '3%'
      },
      color: ['#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: ['热身', '对抗', '控球', '自由', '技战术']
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '高速跑距离',
          type: 'bar',
          barMaxWidth: 40,
          data: [],
          markLine: {
            data: [
              {type: 'average', name: '全组平均值'}
            ]
          }
        }
      ]
    },
    SPRINT_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['冲刺跑距离'],
        top: '3%'
      },
      color: ['#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: ['热身', '对抗', '控球', '自由', '技战术']
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '冲刺跑距离',
          type: 'bar',
          barMaxWidth: 40,
          data: [],
          markLine: {
            data: [
              {type: 'average', name: '全组平均值'}
            ]
          }
        }
      ]
    },
    HIGH_RATE_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['高速跑距离占比'],
        top: '3%'
      },
      color: ['#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: ['热身', '对抗', '控球', '自由', '技战术']
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          max: 100,
          name: '占比(%)',
          splitLine: {
            show: false
          },
          axisLabel: {
            formatter: '{value} %'
          }
        }
      ],
      series: [
        {
          name: '高速跑距离占比',
          type: 'bar',
          barMaxWidth: 40,
          data: [],
          markLine: {
            data: [
              {type: 'average', name: '全组平均值'}
            ]
          }
        }
      ]
    }
  },
  TRAIN_VIEW: {
    TRAIN_ECHARTS: {
      tooltip: {
        formatter: '{a0}<br>{b0}'
      },
      legend: {
        orient: 'vertical',
        top: '20%',
        right: '20%',
        data: ['小学- 200次', '初中- 200次', '高中- 200次']
      },
      color: ['#2d3446', '#c23531', '#61a0a8'],
      series: [
        {
          name: '监控训练次数',
          type: 'pie',
          radius: '60%',
          center: ['25%', '45%'],
          label: {
            normal: {
              show: false
            },
            emphasis: {
              show: false
            }
          },
          data: []
        }
      ]
    },
    PERSON_COUNT: {
      legend: {
        data: ['男', '女']
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#2f4554', '#c23531', '#619fa7', '#91c7ae'],
      grid: {
        left: '4%',
        right: '5%',
        bottom: '22%'
      },
      xAxis: {
        type: 'category',
        axisLabel: {
          rotate: 45,
          interval: 0
        },
        data: []
      },
      yAxis: [
        {
          min: 0,
          name: '人数',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '男',
          type: 'bar',
          barMaxWidth: 40,
          stack: '人数',
          data: []
        },
        {
          name: '女',
          type: 'bar',
          barMaxWidth: 40,
          stack: '人数',
          data: []
        }
      ]
    },
    TIMES_ECHARTS: {
      legend: {
        data: ['小学', '初中', '高中']
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#2f4554', '#619fa7', '#91c7ae'],
      grid: {
        left: '4%',
        right: '5%',
        bottom: '22%'
      },
      xAxis: {
        type: 'category',
        axisLabel: {
          rotate: 45,
          interval: 0
        },
        data: ['北京市', '河南省', '广州']
      },
      yAxis: [
        {
          min: 0,
          name: '次数',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '小学',
          type: 'bar',
          barMaxWidth: 40,
          stack: '次数',
          data: [200, 150, 180]
        },
        {
          name: '初中',
          type: 'bar',
          barMaxWidth: 40,
          stack: '次数',
          data: [200, 150, 180]
        },
        {
          name: '高中',
          type: 'bar',
          barMaxWidth: 40,
          stack: '次数',
          data: [200, 150, 180]
        }
      ]
    }
  }
}

export default TRAIN
