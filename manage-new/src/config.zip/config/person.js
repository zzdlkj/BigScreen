const PERSON = {
  TEAMULTIPLE_ECHARTS: {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    color: ['#f45365', '#96ce57', '#009cdf'],
    legend: {
      data: ['比赛', '训练', '测评'],
      show: false
    },
    grid: {
      left: '3%',
      right: '3%',
      top: '50px',
      bottom: '50px',
      containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        data: [],
        axisLabel: {
          textStyle: {
            color: '#EFF0F1'
          }
        },
        splitLine: {
          show: false
        },
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: ['#484F63']
          }
        }
      }
    ],
    yAxis: [
      {
        type: 'value',
        name: '次',
        nameTextStyle: {
          color: '#A8AFB8'
        },
        axisLabel: {
          textStyle: {
            color: '#A8AFB8'
          }
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ['#484F63']
          }
        },
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: ['#484F63']
          }
        }
      }
    ],
    series: [
      {
        name: '比赛',
        type: 'bar',
        barMaxWidth: '30px',
        stack: 'type',
        data: []
      },
      {
        name: '训练',
        type: 'bar',
        stack: 'type',
        data: []
      },
      {
        name: '测评',
        type: 'bar',
        stack: 'type',
        data: []
      }
    ]
  },
  BOY_ECHARTS: {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    color: ['#6aa9e8'],
    legend: {
      data: [],
      itemGap: 23
    },
    grid: {
      left: '3%',
      right: '3%',
      top: '50px',
      bottom: '70px',
      containLabel: true
    },
    dataZoom: [
      {
        type: 'slider',
        show: true,
        start: 0,
        end: 40
      }
    ],
    xAxis: [
      {
        type: 'category',
        data: [],
        axisLabel: {
          rotate: 45,
          interval: 0,
          textStyle: {
            color: '#666'
          }
        },
        splitLine: {
          show: false
        },
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: ['#e0e0e0']
          }
        }
      }
    ],
    yAxis: [
      {
        type: 'value',
        name: '分',
        nameTextStyle: {
          color: '#666'
        },
        axisLabel: {
          textStyle: {
            color: '#666'
          }
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ['#e0e0e0']
          }
        },
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: ['#e0e0e0']
          }
        }
      },
      {
        type: 'value',
        name: 'bpm',
        show: false,
        nameTextStyle: {
          color: '#666'
        },
        axisLabel: {
          textStyle: {
            color: '#666'
          }
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ['#e0e0e0']
          }
        },
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: ['#e0e0e0']
          }
        }
      }
    ],
    series: [
      {
        name: '测试成绩',
        type: 'bar',
        barMaxWidth: '30px',
        stack: 'type',
        markLine: {
          data: [
            {
              type: 'average',
              name: '团队平均(男)',
              lineStyle: {
                normal: {
                  color: '#96ce57'
                }
              }
            },
            {
              type: 'max',
              name: '团队最高(男)',
              lineStyle: {
                normal: {
                  color: '#f9b621'
                }
              }
            }
          ]
        },
        data: []
      }
    ]
  },
  GIRL_ECHARTS: {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    color: ['#6aa9e8'],
    legend: {
      data: [],
      itemGap: 23
    },
    grid: {
      left: '3%',
      right: '3%',
      top: '50px',
      bottom: '70px',
      containLabel: true
    },
    dataZoom: [
      {
        type: 'slider',
        show: true,
        start: 0,
        end: 40
      }
    ],
    xAxis: [
      {
        type: 'category',
        data: ['李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰'],
        axisLabel: {
          rotate: 45,
          interval: 0,
          textStyle: {
            color: '#666'
          }
        },
        splitLine: {
          show: false
        },
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: ['#e0e0e0']
          }
        }
      }
    ],
    yAxis: [
      {
        type: 'value',
        name: '分',
        nameTextStyle: {
          color: '#666'
        },
        axisLabel: {
          textStyle: {
            color: '#666'
          }
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ['#e0e0e0']
          }
        },
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: ['#e0e0e0']
          }
        }
      },
      {
        type: 'value',
        name: 'bpm',
        show: false,
        nameTextStyle: {
          color: '#666'
        },
        axisLabel: {
          textStyle: {
            color: '#666'
          }
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: ['#e0e0e0']
          }
        },
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: ['#e0e0e0']
          }
        }
      }
    ],
    series: [
      {
        name: '测试成绩',
        type: 'bar',
        barMaxWidth: '30px',
        stack: 'type',
        markLine: {
          data: [
            {
              type: 'average',
              name: '团队平均(男)',
              lineStyle: {
                normal: {
                  color: '#96ce57'
                }
              }
            },
            {
              type: 'max',
              name: '团队最高(男)',
              lineStyle: {
                normal: {
                  color: '#f9b621'
                }
              }
            }
          ]
        },
        data: []
      }
    ]
  },
  LEIDA_ECHARTS: {
    tooltip: {},
    legend: {
      bottom: '0',
      itemWidth: 18,
      data: [
        {
          name: '我',
          icon: 'path://M 200.692 598.5 L 80.53 228.377 L 395.116 -0.335 l 314.586 228.79 L 589.541 598.5 H 200.692 Z',
          textStyle: {
            color: '#ddd'
          }
        },
        {
          name: '他',
          icon: 'path://M 200.692 598.5 L 80.53 228.377 L 395.116 -0.335 l 314.586 228.79 L 589.541 598.5 H 200.692 Z',
          textStyle: {
            color: '#ddd'
          }
        }
      ]
    },
    // grid: {
    //   left: '2%',
    //   right: '2%',
    //   top: '2',
    //   containLabel: true
    // },
    // color: ['#009CDF', '#F45365'],
    color: ['#498bcc', '#cc5274'],
    radar: {
      splitArea: {
        show: false
      },
      name: {
        textStyle: {
          color: '#ddd'
        }
      },
      center: ['50%', '50%'],
      radius: '55%',
      indicator: [
        {name: '跑动距离', max: 6500},
        {name: '跑动距离', max: 1600},
        {name: '跑动距离', max: 3000},
        {name: '跑动距离', max: 5200},
        {name: '跑动距离', max: 6500},
        {name: '跑动距离', max: 6500}
      ]
    },
    series: [
      {
        name: '我 vs 他',
        type: 'radar',
        areaStyle: {normal: {}},
        data: [
          {
            value: [],
            name: '我'
          },
          {
            value: [],
            name: '他'
          }
        ]
      }
    ]
  },
  SIGNOL_ECHARTS: {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    color: ['#009cdf', '#96ce57', '#f45365', '#f9c20d'],
    legend: {
      data: ['速度耐力', '最高运动强度', '变速能力'],
      textStyle: {
        color: '#ddd'
      }
    },
    grid: {
      left: '3%',
      right: '3%',
      top: '50px',
      bottom: '50px',
      containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        nameTextStyle: {
          color: '#A8AFB8'
        },
        data: ['李连杰', '李连杰', '李连杰', '李连杰', '李连杰', '李连杰', '李连杰'],
        axisLabel: {
          rotate: 40,
          textStyle: {
            color: '#ddd'
          }
        },
        splitLine: {
          show: false
        },
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            color: ['#484F63']
          }
        }
      }
    ],
    yAxis: [
      {
        min: 0,
        name: 'm',
        splitLine: {
          show: false,
          lineStyle: {
            color: '#4a5266'
          }
        },
        nameTextStyle: {
          color: '#b8bfc5'
        },
        axisLabel: {
          textStyle: {
            color: '#b8bfc5'
          }
        },
        axisLine: {
          lineStyle: {
            color: '#4a5266'
          }
        },
        axisTick: {
          show: false
        }
      },
      {
        min: 0,
        name: 'PL',
        splitLine: {
          show: true,
          lineStyle: {
            color: '#4a5266'
          }
        },
        nameTextStyle: {
          color: '#b8bfc5'
        },
        axisLabel: {
          textStyle: {
            color: '#b8bfc5'
          }
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: '#4a5266'
          }
        },
        axisTick: {
          show: false
        }
      },
      {
        min: 0,
        max: 100,
        name: '%',
        offset: 40,
        splitLine: {
          show: false,
          lineStyle: {
            color: '#4a5266'
          }
        },
        nameTextStyle: {
          color: '#b8bfc5',
          show: false
        },
        axisLabel: {
          // show: false,
          textStyle: {
            color: '#b8bfc5'
          }
        },
        axisLine: {
          // show: false,
          lineStyle: {
            color: '#4a5266'
          }
        }
      }
    ],
    series: [
      {
        name: '速度耐力',
        type: 'bar',
        barMaxWidth: 25,
        yAxisIndex: 0,
        data: []
      },
      {
        name: '最高运动强度',
        type: 'line',
        symbolSize: 6,
        symbol: 'circle',
        yAxisIndex: 1,
        data: []
      },
      {
        name: '变速能力',
        type: 'line',
        symbolSize: 6,
        symbol: 'circle',
        yAxisIndex: 2,
        data: []
      }
    ]
  },
  TIMES_ECHARTS: {
    title: {
      text: '总次数',
      subtext: '1434',
      left: '50%',
      top: '35%',
      textAlign: 'center',
      textStyle: {
        fontWeight: 'normal',
        fontSize: 14,
        // color: '#ddd'
        color: '#444'
      },
      subtextStyle: {
        fontSize: 24,
        fontWeight: 600,
        // color: '#ddd'
        color: '#444'
      }
    },
    tooltip: {},
    // color: ['#f45365', '#96ce57', '#009cdf'],
    color: ['#db3731', '#444', '#e7bb18'],
    legend: {
      orient: 'vertical',
      right: 5,
      top: '15%',
      show: true,
      itemWidth: 15,
      data: ['比赛次数', '训练次数', '测评次数'],
      textStyle: {
        // color: '#bfb8c5'
        color: '#444'
      }
    },
    grid: {},
    series: [
      {
        name: '总次数',
        type: 'pie',
        radius: ['50%', '80%'],
        roseType: 'radius',
        clockWise: false,
        avoidLabelOverlap: false,
        labelLine: {
          normal: {
            show: false
          }
        },
        data: [
          {name: '比赛次数', value: ''},
          {name: '训练次数', value: ''},
          {name: '测评次数', value: ''}
        ],
        label: {
          normal: {
            show: false,
            position: 'center'
          }
        }
      }
    ]
  },
  LOAD_ECHARTS: {
    color: ['#f45365', '#009cdf'],
    tooltip: {
      formatter: function (params) {
        if (params.name === 'invisible') {
          return ''
        } else {
          return params.name + ' : ' + params.value
        }
      }
    },
    legend: {
      orient: 'vertical',
      right: -5,
      top: '15%',
      itemWidth: 15,
      show: false,
      data: ['身体负荷', '心率负荷'],
      textStyle: {
        color: '#bfb8c5'
      }
    },
    title: {
      text: '',
      subtext: '',
      textAlign: 'center',
      left: '50%',
      // textAlign: 'center',
      top: '40%',
      textStyle: {
        fontWeight: 'normal',
        fontSize: 14,
        color: '#f9c20d'
      },
      subtextStyle: {
        fontSize: 14,
        // fontWeight: 600,
        color: '#ddd'
      }
    },
    series: [
      {
        name: '身体负荷',
        type: 'pie',
        radius: ['75%', '60%'],
        center: ['50%', '50%'],
        itemStyle: {
          normal: {
            label: {show: false},
            labelLine: {show: false},
            shadowBlur: 40,
            shadowColor: 'rgba(40, 40, 40, 0.5)'
          }
        },
        hoverAnimation: false,
        data: [
          {
            value: 548,
            name: '身体负荷'
          },
          {
            value: 152,
            name: 'invisible',
            itemStyle: {
              normal: {
                color: '#555e75',
                label: {show: false},
                labelLine: {show: false}
              },
              emphasis: {
                color: '#555e75'
              }
            }
          }
        ]
      },
      {
        name: '心率负荷',
        type: 'pie',
        radius: ['60%', '50%'],
        itemStyle: {
          normal: {
            label: {show: false},
            labelLine: {show: false},
            shadowBlur: 40,
            shadowColor: 'rgba(40, 40, 40, 0.5)'
          }
        },
        hoverAnimation: false,
        data: [
          {
            value: 478,
            name: '心率负荷'
          },
          {
            value: 222,
            name: 'invisible',
            itemStyle: {
              normal: {
                color: 'rgba(0,0,0,0)',
                label: {show: false},
                labelLine: {show: false}
              },
              emphasis: {
                color: 'rgba(0,0,0,0)'
              }
            }
          }
        ]
      }
    ]
  },
  MONITOR_ECHARTS: {
    color: ['#009cdf', '#96CE57'],
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    legend: {
      data: ['监控次数', '时长'],
      textStyle: {
        color: '#ddd',
        fontSize: 14
      },
      itemGap: 80
    },
    grid: {
      left: 50,
      right: 40,
      top: '22%',
      bottom: '20%'
    },
    xAxis: {
      type: 'category',
      data: [],
      axisLine: {
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisTick: {
        show: false
      },
      axisLabel: {
        rotate: 40,
        interval: 0,
        textStyle: {
          color: '#b8bfc5'
        }
      },
      triggerEvent: true
    },
    yAxis: [
      {
        min: 0,
        name: '次',
        splitLine: {
          show: true,
          lineStyle: {
            color: '#4a5266'
          }
        },
        nameTextStyle: {
          color: '#b8bfc5'
        },
        axisLabel: {
          textStyle: {
            color: '#b8bfc5'
          }
        },
        axisLine: {
          lineStyle: {
            color: '#4a5266'
          }
        },
        axisTick: {
          show: false
        }
      },
      {
        min: 0,
        name: '小时',
        splitLine: {
          show: true,
          lineStyle: {
            color: '#4a5266'
          }
        },
        nameTextStyle: {
          color: '#b8bfc5'
        },
        axisLabel: {
          textStyle: {
            color: '#b8bfc5'
          }
        },
        axisLine: {
          lineStyle: {
            color: '#4a5266'
          }
        },
        axisTick: {
          show: false
        }
      }
    ],
    barGap: '1%',
    series: [
      {
        name: '监控次数',
        type: 'bar',
        barMaxWidth: 25,
        yAxisIndex: 0,
        data: []
      },
      {
        name: '时长',
        type: 'line',
        symbolSize: 6,
        symbol: 'circle',
        yAxisIndex: 1,
        data: []
      }
    ]
  },
  DATACOM_ECHARTS: {
    legend: {
      data: ['速度耐力', '最高运动强度', '变速能力'],
      textStyle: {
        color: '#ddd',
        fontSize: 14
      },
      itemGap: 80
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    color: ['#009cdf', '#96ce57', '#f45365'],
    grid: {
      left: 50,
      right: 80,
      top: '22%',
      bottom: '20%'
    },
    xAxis: {
      type: 'category',
      data: [],
      axisLine: {
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisTick: {
        show: false
      },
      axisLabel: {
        rotate: 45,
        interval: 0,
        textStyle: {
          color: '#b8bfc5'
        }
      },
      triggerEvent: true
    },
    yAxis: [
      {
        min: 0,
        name: 'm',
        splitLine: {
          show: true,
          lineStyle: {
            color: '#4a5266'
          }
        },
        nameTextStyle: {
          color: '#b8bfc5'
        },
        axisLabel: {
          textStyle: {
            color: '#b8bfc5'
          }
        },
        axisLine: {
          lineStyle: {
            color: '#4a5266'
          }
        },
        axisTick: {
          show: false
        }
      },
      {
        min: 0,
        name: 'PL',
        splitLine: {
          show: true,
          lineStyle: {
            color: '#4a5266'
          }
        },
        nameTextStyle: {
          color: '#b8bfc5'
        },
        axisLabel: {
          textStyle: {
            color: '#b8bfc5'
          }
        },
        axisLine: {
          lineStyle: {
            color: '#4a5266'
          }
        },
        axisTick: {
          show: false
        }
      },
      {
        min: 0,
        max: 100,
        name: '%',
        offset: 40,
        splitLine: {
          show: false,
          lineStyle: {
            color: '#4a5266'
          }
        },
        nameTextStyle: {
          color: '#b8bfc5',
          show: false
        },
        axisLabel: {
          // show: false,
          textStyle: {
            color: '#b8bfc5'
          }
        },
        axisLine: {
          // show: false,
          lineStyle: {
            color: '#4a5266'
          }
        }
      }
    ],
    barGap: '1%',
    series: [
      {
        name: '速度耐力',
        type: 'bar',
        barMaxWidth: 25,
        yAxisIndex: 0,
        data: []
      },
      {
        name: '最高运动强度',
        type: 'line',
        symbolSize: 6,
        symbol: 'circle',
        yAxisIndex: 2,
        data: [],
        markPoint: {
          data: [],
          symbolSize: [45, 45],
          label: {
            normal: {
              formatter: '{c}',
              textStyle: {
                color: '#3f4555',
                fontSize: 12
              }
            },
            emphasis: {
              formatter: '{c}',
              textStyle: {
                color: '#3f4555',
                fontSize: 12
              }
            }
          }
        }
      },
      {
        name: '变速能力',
        type: 'line',
        symbolSize: 6,
        symbol: 'circle',
        yAxisIndex: 1,
        data: []
      }
    ]
  },
  BODY_TREND: {
    legend: {
      show: false,
      data: ['身高'],
      textStyle: {
        color: '#ddd',
        fontSize: 14
      },
      itemGap: 80
      // selected: {
      //   '场均高于平均心率人数占比': false
      // }
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    color: ['#96ce57', '#f45365', '#f9c20d'],
    grid: {
      left: 50,
      right: 80,
      top: '22%',
      bottom: '20%'
    },
    xAxis: {
      type: 'category',
      data: ['2012-05-06', '2016-07-08', '2017-04-15'],
      axisLine: {
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisTick: {
        show: false
      },
      axisLabel: {
        interval: 0,
        textStyle: {
          color: '#b8bfc5'
        }
      }
    },
    yAxis: [
      {
        min: 0,
        name: 'cm',
        splitLine: {
          show: true,
          lineStyle: {
            color: '#4a5266'
          }
        },
        nameTextStyle: {
          color: '#b8bfc5'
        },
        axisLabel: {
          textStyle: {
            color: '#b8bfc5'
          }
        },
        axisLine: {
          lineStyle: {
            color: '#4a5266'
          }
        },
        axisTick: {
          show: false
        }
      }
    ],
    barGap: '1%',
    series: [
      {
        name: '身高',
        type: 'line',
        symbolSize: 6,
        symbol: 'circle',
        yAxisIndex: 0,
        data: [
          160, 170, 175
        ],
        markPoint: {
          data: [
            {xAxis: 0, yAxis: 160, value: 160, name: ''},
            {xAxis: 1, yAxis: 170, value: 170, name: ''},
            {xAxis: 2, yAxis: 175, value: 175, name: ''}
          ],
          symbolSize: [45, 45],
          label: {
            normal: {
              formatter: '{c}',
              textStyle: {
                color: '#3f4555',
                fontSize: 12
              }
            },
            emphasis: {
              formatter: '{c}',
              textStyle: {
                color: '#3f4555',
                fontSize: 12
              }
            }
          }
        }
      }
    ]
  },
  JINENG_ECHARTS: {
    legend: {
      data: [],
      textStyle: {
        color: '#ddd',
        fontSize: 14
      },
      itemGap: 80
      // selected: {
      //   '场均高于平均心率人数占比': false
      // }
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    color: ['#009cdf', '#96ce57', '#f45365', '#f9c20d'],
    grid: {
      left: 50,
      right: 80,
      top: '22%',
      bottom: '20%'
    },
    xAxis: {
      type: 'category',
      data: [],
      axisLine: {
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisTick: {
        show: false
      },
      axisLabel: {
        rotate: 45,
        interval: 0,
        textStyle: {
          color: '#b8bfc5'
        }
      }
    },
    yAxis: [
      {
        min: 0,
        name: 'm',
        splitLine: {
          show: true,
          lineStyle: {
            color: '#4a5266'
          }
        },
        nameTextStyle: {
          color: '#b8bfc5'
        },
        axisLabel: {
          textStyle: {
            color: '#b8bfc5'
          }
        },
        axisLine: {
          lineStyle: {
            color: '#4a5266'
          }
        },
        axisTick: {
          show: false
        }
      },
      {
        min: 0,
        name: 'PL',
        splitLine: {
          show: true,
          lineStyle: {
            color: '#4a5266'
          }
        },
        nameTextStyle: {
          color: '#b8bfc5'
        },
        axisLabel: {
          textStyle: {
            color: '#b8bfc5'
          }
        },
        axisLine: {
          lineStyle: {
            color: '#4a5266'
          }
        },
        axisTick: {
          show: false
        }
      },
      {
        min: 0,
        max: 100,
        name: '%',
        offset: 40,
        splitLine: {
          show: false,
          lineStyle: {
            color: '#4a5266'
          }
        },
        nameTextStyle: {
          color: '#b8bfc5',
          show: false
        },
        axisLabel: {
          // show: false,
          textStyle: {
            color: '#b8bfc5'
          }
        },
        axisLine: {
          // show: false,
          lineStyle: {
            color: '#4a5266'
          }
        }
      }
    ],
    barGap: '1%',
    series: [
      {
        type: 'bar',
        barMaxWidth: 25,
        yAxisIndex: 0,
        data: []
      },
      {
        type: 'line',
        symbolSize: 6,
        symbol: 'circle',
        yAxisIndex: 2,
        data: [],
        markPoint: {
          data: [],
          symbolSize: [45, 45],
          label: {
            normal: {
              formatter: '{c}',
              textStyle: {
                color: '#3f4555',
                fontSize: 12
              }
            },
            emphasis: {
              formatter: '{c}',
              textStyle: {
                color: '#3f4555',
                fontSize: 12
              }
            }
          }
        }
      },
      {
        type: 'line',
        symbolSize: 6,
        symbol: 'circle',
        yAxisIndex: 1,
        data: []
      }
    ]
  },
  fUNCTION_ADVANCE: {
    legend: {
      data: [],
      selected: {},
      textStyle: {
        // color: '#ddd',
        color: '#444',
        fontSize: 12
      },
      itemGap: 20
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    color: [],
    grid: {
      left: 50,
      right: 110,
      top: '22%',
      bottom: '20%'
    },
    xAxis: {
      type: 'category',
      data: [],
      axisLine: {
        lineStyle: {
          // color: '#4a5266'
          color: '#bbb'
        }
      },
      axisTick: {
        show: false
      },
      axisLabel: {
        rotate: 45,
        interval: 0,
        textStyle: {
          // color: '#b8bfc5'
          color: '#444'
        }
      }
    },
    yAxis: [
      {
        min: 0,
        name: 'm',
        splitLine: {
          show: true,
          lineStyle: {
            // color: '#4a5266'
            color: '#bbb'
          }
        },
        nameTextStyle: {
          // color: '#b8bfc5'
          color: '#444'
        },
        axisLabel: {
          textStyle: {
            // color: '#b8bfc5'
            color: '#444'
          }
        },
        axisLine: {
          lineStyle: {
            // color: '#4a5266'
            color: '#bbb'
          }
        },
        axisTick: {
          show: false
        }
      },
      {
        min: 0,
        name: 'm/s',
        splitLine: {
          show: true,
          lineStyle: {
            // color: '#4a5266'
            color: '#bbb'
          }
        },
        nameTextStyle: {
          color: '#444'
          // color: '#b8bfc5'
        },
        axisLabel: {
          textStyle: {
            color: '#444'
            // color: '#b8bfc5'
          }
        },
        axisLine: {
          lineStyle: {
            // color: '#4a5266'
            color: '#bbb'
          }
        },
        axisTick: {
          show: false
        }
      },
      {
        min: 0,
        name: 'PL',
        offset: 55,
        splitLine: {
          show: false,
          lineStyle: {
            color: '#bbb'
          }
        },
        nameTextStyle: {
          color: '#444',
          show: false
        },
        axisLabel: {
          // show: false,
          textStyle: {
            color: '#444'
          }
        },
        axisLine: {
          // show: false,
          lineStyle: {
            color: '#bbb'
          }
        }
      }
    ],
    barGap: '1%',
    series: [
      {
        type: 'bar',
        barMaxWidth: 25,
        yAxisIndex: 0,
        data: []
      },
      {
        type: 'line',
        symbolSize: 6,
        symbol: 'circle',
        yAxisIndex: 1,
        data: []
      },
      {
        type: 'line',
        symbolSize: 6,
        symbol: 'circle',
        yAxisIndex: 2,
        data: []
      },
      {
        type: 'bar',
        barMaxWidth: 25,
        yAxisIndex: 0,
        data: []
      },
      {
        type: 'line',
        symbolSize: 6,
        symbol: 'circle',
        yAxisIndex: 0,
        data: []
      },
      {
        type: 'line',
        symbolSize: 6,
        symbol: 'circle',
        yAxisIndex: 0,
        data: []
      },
      {
        type: 'line',
        symbolSize: 6,
        symbol: 'circle',
        yAxisIndex: 0,
        data: []
      }
    ]
  },
  fUNCTION_ITEMS: [
    {
      name: '最大高强度跑距离/min',
      yAxis: 'm',
      type: 'bar'
    },
    {
      name: '最高速度',
      yAxis: 'm/s',
      type: 'line'
    },
    {
      name: '最大水平身体负荷/min',
      yAxis: 'PL',
      type: 'line'
    },
    {
      name: '最高代谢功率',
      yAxis: 'W/kg',
      type: 'bar'
    },
    {
      name: '最高心率强度',
      yAxis: '%',
      type: 'line'
    },
    {
      name: '最大心率负荷/min',
      yAxis: 'PL',
      type: 'line'
    },
    {
      name: '最大心率',
      yAxis: 'bpm',
      type: 'line'
    }
  ],
  LEVEL_ECHARTS: {
    // legend: {
    //   data: ['跑动距离', '高强度跑距离', '平均心率', '最大心率'],
    //   textStyle: {
    //     color: '#fff'
    //   }
    // },
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    color: ['#009cdf', '#f45365', '#96ce57', '#f9c20d'],
    grid: {
      left: '2%',
      right: '20%',
      bottom: '22%'
    },
    xAxis: {
      type: 'category',
      data: ['基本心率', '最大心率', '指标3', '指标4'],
      axisLine: {
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisTick: {
        show: false
      },
      axisLabel: {
        rotate: 45,
        interval: 0,
        textStyle: {
          color: '#ececed',
          fontSize: 14
        }
      }
    },
    yAxis: [
      {
        min: 0,
        splitLine: {
          show: true,
          lineStyle: {
            color: '#4a5266'
          }
        },
        axisLabel: {
          show: false,
          textStyle: {
            color: '#b8bfc5'
          }
        },
        axisLine: {
          lineStyle: {
            color: '#4a5266'
          }
        },
        axisTick: {
          show: false
        }
      }
    ],
    barGap: '1%',
    series: [
      {
        name: '心率指标',
        type: 'bar',
        barMaxWidth: 30,
        data: [],
        label: {
          normal: {
            show: true,
            position: 'top',
            textStyle: {
              color: '#fff'
            }
          }
        },
        markLine: {
          label: {
            normal: {
              position: 'end',
              formatter: '{b}: {c}',
              textStyle: {
                color: '#fff'
              }
            },
            emphasis: {
              position: 'end',
              formatter: '{b}:{c}',
              textStyle: {
                color: '#fff'
              }
            }
          },
          data: [
            {
              name: '全国平均',
              yAxis: 120,
              lineStyle: {
                normal: {
                  color: '#96ce57',
                  type: 'solid'
                }
              }
            },
            {
              name: '全国最高',
              yAxis: 200,
              lineStyle: {
                normal: {
                  color: '#f45365',
                  type: 'solid'
                }
              }
            }
          ]
        }
      }
    ]
  },
  COMPARE_CHART: {
    legend: {
      data: ['', '全国平均', '全国最高'],
      left: 135,
      itemWidth: 20,
      itemHeight: 2,
      top: -5,
      textStyle: {
        color: '#ddd'
      }
    },
    tooltip: {
      trigger: 'axis',
      textStyle: {
        fontSize: 12
      },
      axisPointer: {
        type: 'shadow'
      }
    },
    color: ['#009cdf', '#f45365', '#96ce57', '#f9c20d'],
    grid: {
      left: 135,
      top: 30,
      right: '2%',
      bottom: '4%'
    },
    yAxis: {
      type: 'category',
      data: ['平均速度m/s', '基本心率bpm', '高速跑距离m', '跑动距离m'],
      // boundaryGap: false,
      axisLine: {
        show: false,
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisTick: {
        show: false
      },
      axisLabel: {
        textStyle: {
          color: '#ddd',
          fontSize: 14
        }
      }
    },
    xAxis: {
      min: 0,
      max: 115,
      splitLine: {
        show: false,
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisLabel: {
        show: false,
        textStyle: {
          color: '#b8bfc5'
        }
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisTick: {
        show: false
      }
    },
    barGap: '1%',
    series: [
      {
        name: '我',
        type: 'bar',
        stack: '我',
        barMaxWidth: 25,
        z: 19,
        data: [40, 40, 40, 40],
        label: {
          normal: {
            show: true,
            position: 'right',
            textStyle: {
              color: '#eee'
            },
            formatter: ''
          }
        }
      },
      {
        name: '运动指标',
        type: 'bar',
        stack: '我',
        barMaxWidth: 25,
        data: [60, 60, 60, 60],
        itemStyle: {
          normal: {
            color: '#555e75'
          }
        }
      },
      {
        name: '全国平均',
        type: 'scatter',
        symbol: 'roundRect',
        hoverAnimation: false,
        silent: true,
        itemStyle: {
          normal: {
            color: '#96ce57'
          }
        },
        symbolSize: [3, 25],
        z: 20,
        data: [30, 80, 50, 30]
      },
      {
        name: '全国最高',
        type: 'scatter',
        symbol: 'roundRect',
        hoverAnimation: false,
        silent: true,
        itemStyle: {
          normal: {
            color: '#f45365'
          }
        },
        symbolSize: [3, 25],
        z: 20,
        data: [100, 100, 100, 100]
      }
    ]
  },
  COMPARE_CHARTs: {
    legend: {
      data: [''],
      left: 135,
      itemWidth: 20,
      itemHeight: 2,
      top: -5,
      textStyle: {
        // color: '#ddd'
        color: '#444'
      }
    },
    tooltip: {
      show: false,
      trigger: 'axis',
      textStyle: {
        fontSize: 12
      },
      axisPointer: {
        type: 'shadow'
      }
    },
    // color: ['#009cdf', '#f45365', '#96ce57', '#f9c20d'],
    color: ['#db3731', '#444', '#96ce57', '#f9c20d'],
    grid: {
      left: 120,
      top: 0,
      right: '6%',
      bottom: '4%'
    },
    yAxis: {
      type: 'category',
      data: ['平均速度m/s', '基本心率bpm', '高速跑距离m', '跑动距离m'],
      // boundaryGap: false,
      axisLine: {
        show: false,
        lineStyle: {
          // color: '#4a5266'
          color: '#bbb'
        }
      },
      axisTick: {
        show: false
      },
      axisLabel: {
        textStyle: {
          color: '#444',
          fontSize: 14
        }
      }
    },
    xAxis: {
      min: 0,
      max: 115,
      splitLine: {
        show: false,
        lineStyle: {
          // color: '#4a5266'
          color: '#bbb'
        }
      },
      axisLabel: {
        show: false,
        textStyle: {
          // color: '#b8bfc5'
          color: '#444'
        }
      },
      axisLine: {
        show: false,
        lineStyle: {
          // color: '#4a5266'
          color: '#bbb'
        }
      },
      axisTick: {
        show: false
      }
    },
    barGap: '1%',
    series: [
      {
        name: '我',
        type: 'bar',
        stack: '我',
        barMaxWidth: 15,
        z: 19,
        data: [40, 40, 40, 40],
        label: {
          normal: {
            show: true,
            position: 'right',
            textStyle: {
              // color: '#eee'
              color: '#f2c933'
            },
            formatter: ''
          }
        }
      },
      {
        name: '运动指标',
        type: 'bar',
        stack: '我',
        barMaxWidth: 15,
        data: [60, 60, 60, 60],
        itemStyle: {
          normal: {
            color: '#444'
            // color: '#555e75'
          }
        }
      }
    ]
  },
  SPORT_ECHARTS: {
    legend: {
      data: [''],
      top: '4%',
      left: '24%',
      textStyle: {
        color: '#fff'
      }
    },
    tooltip: {
      trigger: 'axis',
      textStyle: {
        fontSize: 12
      },
      axisPointer: {
        type: 'shadow'
      }
    },
    color: ['#009cdf', '#f45365', '#96ce57', '#f9c20d'],
    grid: {
      left: '25%',
      right: '2%',
      top: '10%',
      bottom: '5%'
    },
    yAxis: {
      type: 'category',
      data: ['平均速度 m/s', '基本心率bpm', '高速跑距离 m', '跑动距离 m'],
      // boundaryGap: false,
      axisLine: {
        show: false,
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisTick: {
        show: false
      },
      axisLabel: {
        textStyle: {
          color: '#ececed',
          fontSize: 14
        }
      }
    },
    xAxis: {
      min: 0,
      max: 110,
      splitLine: {
        show: false,
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisLabel: {
        show: false,
        textStyle: {
          color: '#b8bfc5'
        }
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisTick: {
        show: false
      }
    },
    barGap: '1%',
    series: [
      {
        name: '我',
        type: 'bar',
        stack: '我',
        barMaxWidth: 30,
        data: [40, 40, 40, 40],
        markLine: {
          label: {
            normal: {
              position: 'end',
              formatter: '{b}',
              textStyle: {
                color: '#fff'
              }
            },
            emphasis: {
              position: 'end',
              formatter: '{b}',
              textStyle: {
                color: '#fff'
              }
            }
          },
          data: [
            {
              name: '全国平均',
              xAxis: 50,
              lineStyle: {
                normal: {
                  color: '#96ce57',
                  type: 'solid'
                }
              }
            },
            {
              name: '全国最高',
              xAxis: 100,
              lineStyle: {
                normal: {
                  color: '#f45365',
                  type: 'solid'
                }
              }
            }
          ]
        }
      },
      {
        name: '运动指标',
        type: 'bar',
        stack: '我',
        barMaxWidth: 30,
        data: [60, 60, 60, 60],
        itemStyle: {
          normal: {
            color: '#555e75'
          }
        }
      }
    ]
  },
  RECORD_ECHARTS: {
    legend: {
      data: ['平均', '最高'],
      orient: 'vertical',
      top: '8%',
      right: '5%',
      textStyle: {
        color: '#fff'
      }
    },
    color: ['#009cdf', '#f45365', '#96ce57', '#f9c20d'],
    grid: {
      top: '5%',
      left: '15%',
      right: '20%',
      bottom: '5%'
    },
    yAxis: {
      type: 'category',
      data: ['指标5', '指标4', '速度 m/s', '跑动距离 m', '平均心率'],
      // boundaryGap: false,
      axisLine: {
        show: false,
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisTick: {
        show: false
      },
      axisLabel: {
        textStyle: {
          color: '#ececed',
          fontSize: 14
        }
      }
    },
    xAxis: {
      min: 0,
      max: 110,
      splitLine: {
        show: false,
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisLabel: {
        show: false,
        textStyle: {
          color: '#b8bfc5'
        }
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisTick: {
        show: false
      }
    },
    barGap: '1%',
    series: [
      {
        name: '平均',
        type: 'bar',
        stack: '数值',
        barMaxWidth: 30,
        data: [],
        label: {
          normal: {
            show: true,
            position: 'inside',
            formatter: '',
            textStyle: {
              color: '#fff'
            }
          }
        }
      },
      {
        name: '最高',
        type: 'bar',
        stack: '数值',
        barMaxWidth: 30,
        data: [],
        itemStyle: {
          normal: {
            color: '#555e75'
          }
        },
        label: {
          normal: {
            show: true,
            position: 'right',
            formatter: '',
            textStyle: {
              color: '#fff'
            }
          }
        }
      }
    ]
  },
  TREND: {
    legend: {
      data: ['Punch Card'],
      show: false,
      left: 'right'
    },
    grid: {
      left: 2,
      top: '5%',
      bottom: '20%',
      right: 10,
      containLabel: true
    },
    tooltip: {
      formatter: function (params) {
      }
    },
    dataZoom: [
      {
        show: true,
        realtime: true,
        start: 0,
        end: 70,
        textStyle: {
          color: '#eee'
        },
        borderColor: '#444a5c',
        fillerColor: '#444a5c',
        handleStyle: {
          color: '#555e75'
        }
      },
      {
        type: 'inside',
        realtime: true,
        start: 0,
        end: 70
      }
    ],
    xAxis: {
      type: 'category',
      data: [],
      axisLabel: {
        textStyle: {
          color: '#ddd'
        }
      },
      axisLine: {
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisTick: {
        show: false
      },
      splitLine: {
        show: false
      }
    },
    yAxis: {
      type: 'category',
      data: [],
      axisLine: {
        lineStyle: {
          color: '#4a5266'
        }
      },
      axisTick: {
        show: false
      },
      axisLabel: {
        textStyle: {
          color: '#ddd'
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: '#4a5266'
        }
      }
    },
    series: [{
      name: 'Punch Card',
      type: 'scatter',
      symbolSize: function (val) {
        return val[2] / 2
      },
      data: []
      // animationDelay: function (idx) {
      //   return idx * 5;
      // }
    }]
  },
  TREND_ECHARTS: {
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'shadow'
      }
    },
    // color: ['#f45365', '#96ce57', '#009cdf'],
    color: ['#db3731', '#444', '#e7bb18'],
    legend: {
      data: ['比赛', '训练', '测评'],
      show: false
    },
    grid: {
      left: '3%',
      right: '3%',
      top: '50px',
      bottom: '50px',
      containLabel: true
    },
    xAxis: [
      {
        type: 'category',
        data: [],
        axisLabel: {
          textStyle: {
            // color: '#EFF0F1'
            color: '#444'
          }
        },
        splitLine: {
          show: false
        },
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            // color: ['#484F63']
            color: ['#bbb']
          }
        }
      }
    ],
    yAxis: [
      {
        type: 'value',
        name: '次',
        nameTextStyle: {
          // color: '#A8AFB8'
          color: '#444'
        },
        axisLabel: {
          textStyle: {
            // color: '#A8AFB8'
            color: '#444'
          }
        },
        splitLine: {
          show: true,
          lineStyle: {
            // color: ['#484F63']
            color: ['#bbb']
          }
        },
        axisTick: {
          show: false
        },
        axisLine: {
          lineStyle: {
            // color: ['#484F63']
            color: ['#bbb']
          }
        }
      }
    ],
    series: [
      {
        name: '比赛',
        type: 'bar',
        stack: '搜索引擎',
        data: []
      },
      {
        name: '训练',
        type: 'bar',
        barMaxWidth: '30px',
        stack: '搜索引擎',
        data: []
      }
      // {
      //   name: '测评',
      //   type: 'bar',
      //   stack: '搜索引擎',
      //   data: []
      // }
    ]
  },
  ORG_FUN_STATUE: {
    tooltip: {},
    legend: {
      bottom: '0',
      show: false,
      itemWidth: 18,
      data: []
    },
    // grid: {
    //   left: '2%',
    //   right: '2%',
    //   top: '2',
    //   containLabel: true
    // },
    // color: ['#009CDF', '#F45365'],
    color: ['#498bcc', '#cc5274'],
    radar: {
      splitArea: {
        show: false
      },
      name: {
        textStyle: {
          color: '#ddd'
        }
      },
      center: ['50%', '50%'],
      radius: '50%',
      indicator: [
        {name: '速度能力\n(m/s)', max: 12},
        {name: '最高运动强度', max: 100},
        {name: '爆发能力\n(W/kg)', max: 40},
        {name: '变速能力\n(PL)', max: 10},
        {name: '速度耐力\n(m)', max: 6000},
        {name: '一般耐力\n(m/20min)', max: 100000}
      ]
    },
    series: [
      {
        name: '我 vs 他',
        type: 'radar',
        areaStyle: {normal: {}},
        data: [
          {
            value: [],
            name: '我'
          }
        ]
      }
    ]
  },
  DISTANCE_PIE: {
    color: ['#96ce57', '#f9c20d'],
    tooltip: {
      formatter: function (params) {
        if (params.name === 'invisible') {
          return ''
        } else {
          return params.name + ' : ' + params.value
        }
      }
    },
    legend: {
      orient: 'vertical',
      right: -5,
      top: '15%',
      itemWidth: 15,
      show: false,
      data: ['跑动距离', '高强度跑距离'],
      textStyle: {
        color: '#bfb8c5'
      }
    },
    title: {
      text: '',
      subtext: '',
      left: 'center',
      top: '40%',
      textStyle: {
        fontWeight: 'normal',
        fontSize: 14,
        color: '#f9c20d'
      },
      subtextStyle: {
        fontSize: 14,
        // fontWeight: 600,
        color: '#ddd'
      }
    },
    series: [
      {
        name: '跑动距离',
        type: 'pie',
        radius: ['75%', '60%'],
        center: ['50%', '50%'],
        itemStyle: {
          normal: {
            label: {show: false},
            labelLine: {show: false},
            shadowBlur: 40,
            shadowColor: 'rgba(40, 40, 40, 0.5)'
          }
        },
        hoverAnimation: false,
        data: [
          {
            value: 3866,
            name: '跑动距离'
          },
          {
            value: 686,
            name: 'invisible',
            itemStyle: {
              normal: {
                color: '#555e75',
                label: {show: false},
                labelLine: {show: false}
              },
              emphasis: {
                color: '#555e75'
              }
            }
          }
        ]
      },
      {
        name: '高强度跑距离',
        type: 'pie',
        radius: ['60%', '50%'],
        itemStyle: {
          normal: {
            label: {show: false},
            labelLine: {show: false},
            shadowBlur: 40,
            shadowColor: 'rgba(40, 40, 40, 0.5)'
          }
        },
        hoverAnimation: false,
        data: [
          {
            value: 686,
            name: '高强度跑距离'
          },
          {
            value: 3866,
            name: 'invisible',
            itemStyle: {
              normal: {
                color: 'rgba(0,0,0,0)',
                label: {show: false},
                labelLine: {show: false}
              },
              emphasis: {
                color: 'rgba(0,0,0,0)'
              }
            }
          }
        ]
      }
    ]
  },
  TEST_REPORT: {
    COMPARE_CHART: {
      legend: {
        data: ['', '全国平均', '全国最高'],
        left: 135,
        itemWidth: 20,
        itemHeight: 2,
        top: -5,
        textStyle: {
          color: '#333'
        }
      },
      tooltip: {
        trigger: 'axis',
        textStyle: {
          fontSize: 12
        },
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#009cdf'],
      grid: {
        left: 150,
        top: 50,
        right: '2%',
        bottom: '5%'
      },
      yAxis: {
        type: 'category',
        data: [],
        // boundaryGap: false,
        axisLine: {
          show: false,
          lineStyle: {
            color: '#4a5266'
          }
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          show: true,
          textStyle: {
            color: '#333',
            fontSize: 14,
            fontWeight: 'bold'
          }
        }
      },
      xAxis: {
        min: 0,
        max: 100,
        splitLine: {
          show: false,
          lineStyle: {
            color: '#4a5266'
          }
        },
        axisLabel: {
          show: false,
          textStyle: {
            color: '#b8bfc5'
          }
        },
        axisLine: {
          show: false,
          lineStyle: {
            color: '#4a5266'
          }
        },
        axisTick: {
          show: false
        }
      },
      barGap: '1%',
      series: [
        {
          name: '我',
          type: 'bar',
          stack: '我',
          barMaxWidth: 24,
          barGap: 16,
          z: 19,
          data: [40, 40, 40, 40],
          label: {
            normal: {
              show: true,
              position: 'right',
              textStyle: {
                color: '#666'
              },
              formatter: ''
            }
          }
        },
        {
          name: '运动指标',
          type: 'bar',
          stack: '我',
          barMaxWidth: 25,
          barGap: 16,
          data: [60, 60, 60, 60],
          itemStyle: {
            normal: {
              color: '#e6e6e6'
            }
          }
        },
        {
          name: '全国平均',
          type: 'scatter',
          symbol: 'roundRect',
          hoverAnimation: false,
          silent: true,
          itemStyle: {
            normal: {
              color: '#96ce57'
            }
          },
          symbolSize: [3, 25],
          z: 20,
          data: [30, 80, 50, 30]
        },
        {
          name: '全国最高',
          type: 'scatter',
          symbol: 'roundRect',
          hoverAnimation: false,
          silent: true,
          itemStyle: {
            normal: {
              color: '#f9c20d'
            }
          },
          symbolSize: [3, 25],
          z: 20,
          data: [100, 100, 100, 100]
        }
      ]
    }
  },
  MATCH_REPORT: {
    SPEEDS_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['队伍平均', '队伍历史平均', '高水平队伍'],
        show: false
      },
      color: ['#6aa9e8', '#96ce57', '#f9c20d'],
      grid: {
        left: '3%',
        right: '3%',
        top: '50px',
        bottom: '50px',
        containLabel: true
      },
      xAxis: [
        {
          type: 'category',
          data: ['走慢跑  [0, 2.3)', '低速跑  [2.3, 2.9)', '中速跑  [2.9, 3.9)', '快速跑  [3.9, 4.8)', '高速跑  [4.8, 6.1)', '冲刺跑  [6.1, --)'].map(k => {
            return k.split('  ').join('\n')
          }),
          axisLabel: {
            textStyle: {
              color: '#333'
            }
          },
          splitLine: {
            show: true
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '距离(m)',
          nameTextStyle: {
            color: '#333'
          },
          axisLabel: {
            textStyle: {
              color: '#333'
            }
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '队伍平均',
          type: 'bar',
          barMaxWidth: '30px',
          data: [210, 230, 435, 435, 563, 574],
          label: {
            normal: {
              show: true,
              position: 'top',
              formatter: function (val) {
                return val.data + ' (20%)'
              }
            }
          }
        },
        {
          name: '队伍历史平均',
          type: 'line',
          symbol: 'circle',
          data: []
        },
        {
          name: '高水平队伍',
          type: 'line',
          symbol: 'circle',
          data: []
        }
      ]
    },
    SPEEDS_RED_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['红队人均', '队伍历史人均', '高水平队伍'],
        show: false
      },
      color: ['#ec6a86', '#96ce57', '#f9c20d'],
      grid: {
        left: '3%',
        right: '3%',
        top: '50px',
        bottom: '50px',
        containLabel: true
      },
      xAxis: [
        {
          type: 'category',
          data: ['走慢跑  [0, 2.3)', '低速跑  [2.3, 2.9)', '中速跑  [2.9, 3.9)', '快速跑  [3.9, 4.8)', '高速跑  [4.8, 6.1)', '冲刺跑  [6.1, --)'].map((k, i) => {
            return k.split('  ').join('\n')
          }),
          axisLabel: {
            textStyle: {
              color: '#333'
            }
          },
          splitLine: {
            show: true
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '距离(m)',
          nameTextStyle: {
            color: '#333'
          },
          axisLabel: {
            textStyle: {
              color: '#333'
            }
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '红队人均',
          type: 'bar',
          barMaxWidth: '30px',
          data: [210, 230, 435, 435, 563, 574],
          label: {
            normal: {
              show: true,
              position: 'top',
              formatter: function (val) {
                return val.data + ' (20%)'
              }
            }
          }
        },
        {
          name: '队伍历史人均',
          type: 'line',
          symbol: 'circle',
          data: [230, 240, 477, 422, 534, 524]
        },
        {
          name: '高水平队伍',
          type: 'line',
          symbol: 'circle',
          data: [240, 220, 423, 443, 512, 500]
        }
      ]
    },
    SPEEDS_BLUE_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['蓝队人均', '队伍历史人均', '高水平队伍'],
        show: false
      },
      color: ['#6aa9e8', '#96ce57', '#f9c20d'],
      grid: {
        left: '3%',
        right: '3%',
        top: '50px',
        bottom: '50px',
        containLabel: true
      },
      xAxis: [
        {
          type: 'category',
          data: ['走慢跑  [0, 2.3)', '低速跑  [2.3, 2.9)', '中速跑  [2.9, 3.9)', '快速跑  [3.9, 4.8)', '高速跑  [4.8, 6.1)', '冲刺跑  [6.1, --)'].map((k, i) => {
            return k.split('  ').join('\n')
          }),
          axisLabel: {
            textStyle: {
              color: '#333'
            }
          },
          splitLine: {
            show: true
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '距离(m)',
          nameTextStyle: {
            color: '#333'
          },
          axisLabel: {
            textStyle: {
              color: '#333'
            }
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '蓝队人均',
          type: 'bar',
          barMaxWidth: '30px',
          data: [210, 230, 435, 435, 563, 574],
          label: {
            normal: {
              show: true,
              position: 'top',
              formatter: function (val) {
                return val.data + ' (20%)'
              }
            }
          }
        },
        {
          name: '队伍历史人均',
          type: 'line',
          symbol: 'circle',
          data: [230, 240, 477, 422, 534, 524]
        },
        {
          name: '高水平队伍',
          type: 'line',
          symbol: 'circle',
          data: [240, 220, 423, 443, 512, 500]
        }
      ]
    },
    HRTIMES_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['队伍平均', '队伍历史平均'],
        show: false
      },
      color: ['#6aa9e8', '#96ce57', '#f9c20d'],
      grid: {
        left: '3%',
        right: '3%',
        top: '50px',
        bottom: '50px',
        containLabel: true
      },
      xAxis: [
        {
          type: 'category',
          data: ['区间1  [0, 65%)', '区间2  [66%, 71%)', '区间3  [72%, 78%)', '区间4  [79%, 85%)', '区间5  [86%, 92%)', '区间6  [93%, 100%)'].map(k => {
            return k.split('  ').join('\n')
          }),
          axisLabel: {
            textStyle: {
              color: '#333'
            },
            interval: 0
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '时间(min)',
          nameTextStyle: {
            color: '#333'
          },
          axisLabel: {
            textStyle: {
              color: '#333'
            }
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '队伍平均',
          type: 'bar',
          barMaxWidth: '30px',
          data: [210, 230, 435, 435, 563, 574],
          label: {
            normal: {
              show: true,
              position: 'top',
              formatter: function (val) {
                return val.data + ' (20%)'
              }
            }
          }
        },
        {
          name: '队伍历史平均',
          type: 'line',
          symbol: 'circle',
          data: []
        }
      ]
    },
    HRTIMES_RED_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['红队人均', '队伍历史人均'],
        show: false
      },
      color: ['#ec6a86', '#96ce57', '#f9c20d'],
      grid: {
        left: '3%',
        right: '3%',
        top: '50px',
        bottom: '50px',
        containLabel: true
      },
      xAxis: [
        {
          type: 'category',
          data: ['区间一  [0, 65%)', '区间二  [66%, 71%)', '区间三  [72%, 78%)', '区间四  [79%, 85%)', '区间五  [86%, 92%)', '区间六  [93%, 100%)'].map((k, i) => {
            return k.split('  ').join('\n')
          }),
          axisLabel: {
            textStyle: {
              color: '#333'
            },
            interval: 0
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '时间(min)',
          nameTextStyle: {
            color: '#333'
          },
          axisLabel: {
            textStyle: {
              color: '#333'
            }
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '红队人均',
          type: 'bar',
          barMaxWidth: '30px',
          data: [210, 230, 435, 435, 563, 574],
          label: {
            normal: {
              show: true,
              position: 'top',
              formatter: function (val) {
                return val.data + ' (20%)'
              }
            }
          }
        },
        {
          name: '队伍历史人均',
          type: 'line',
          symbol: 'circle',
          data: [230, 240, 477, 422, 534, 524]
        }
      ]
    },
    HRTIMES_BLUE_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['蓝队人均', '队伍历史人均'],
        show: false
      },
      color: ['#6aa9e8', '#96ce57', '#f9c20d'],
      grid: {
        left: '3%',
        right: '3%',
        top: '50px',
        bottom: '50px',
        containLabel: true
      },
      xAxis: [
        {
          type: 'category',
          data: ['区间一  [0, 65%)', '区间二  [66%, 71%)', '区间三  [72%, 78%)', '区间四  [79%, 85%)', '区间五  [86%, 92%)', '区间六  [93%, 100%)'].map((k, i) => {
            return k.split('  ').join('\n')
          }),
          axisLabel: {
            textStyle: {
              color: '#333'
            },
            interval: 0
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '时间(min)',
          nameTextStyle: {
            color: '#333'
          },
          axisLabel: {
            textStyle: {
              color: '#333'
            }
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '蓝队人均',
          type: 'bar',
          barMaxWidth: '30px',
          data: [210, 230, 435, 435, 563, 574],
          label: {
            normal: {
              show: true,
              position: 'top',
              formatter: function (val) {
                return val.data + ' (20%)'
              }
            }
          }
        },
        {
          name: '队伍历史人均',
          type: 'line',
          symbol: 'circle',
          data: [230, 240, 477, 422, 534, 524]
        }
      ]
    },
    RANKDATA_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#6aa9e8', '#ec6a86', '#f9c20d'],
      legend: {
        data: ['跑动距离', '高强度跑距离', '最高速度']
      },
      grid: {
        left: '3%',
        right: '3%',
        top: '120px',
        bottom: '80px',
        containLabel: true
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          startValue: 0,
          endValue: 25
        }
      ],
      xAxis: [
        {
          type: 'category',
          data: ['李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰'],
          axisLabel: {
            textStyle: {
              color: '#666'
            },
            rotate: 45
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: 'm',
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        },
        {
          type: 'value',
          name: '高强度跑(m)',
          show: false,
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        },
        {
          type: 'value',
          name: 'm/s',
          show: false,
          position: 'right',
          offset: 50,
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          barMaxWidth: '30px',
          data: [100, 20, 70, 60, 90, 96, 100, 80, 80, 60, 100, 20, 70, 60, 90, 96, 100, 80, 80, 60]
        },
        {
          name: '高强度跑距离',
          type: 'bar',
          barMaxWidth: '30px',
          data: [100, 20, 70, 60, 90, 96, 100, 80, 80, 60, 100, 20, 70, 60, 90, 96, 100, 80, 80, 60]
        },
        {
          name: '最高速度',
          type: 'line',
          barMaxWidth: '30px',
          symbol: 'circle',
          data: [100, 20, 70, 60, 90, 96, 100, 80, 80, 60, 100, 20, 70, 60, 90, 96, 100, 80, 80, 60]
        }
      ]
    },
    SPEED_DISTENCE_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#6aa9e8', '#6aa9e8', '#ec6a86', '#ec6a86'],
      legend: {
        data: ['跑动距离', '队伍人均跑动距离', '高强度跑距离', '队伍人均高强度跑距离']
      },
      grid: {
        left: '3%',
        right: '3%',
        top: '120px',
        bottom: '50px',
        containLabel: true
      },
      // dataZoom: [
      //   {
      //     type: 'slider',
      //     show: true,
      //     start: 0,
      //     end: 100
      //   }
      // ],
      xAxis: [
        {
          type: 'category',
          data: ['0\'', '5\'', '10\'', '15\'', '20\'', '25\'', '30\'', '35\'', '40\'', '45\'', '中场休息', '45\'', '50\'', '55\'', '60\'', '65\'', '70\'', '75\'', '80\'', '85\''],
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          boundaryGap: ['20%', '50%'],
          splitLine: {
            show: false
          },
          axisTick: {
            show: true
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '跑动距离(m)',
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        },
        {
          type: 'value',
          name: '高强度跑距离(m)',
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          barMaxWidth: '30px',
          // stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          data: []
        },
        {
          name: '队伍人均跑动距离',
          type: 'line',
          barMaxWidth: '30px',
          // stack: 'type',
          symbol: 'circle',
          symbolSize: 8,
          data: []
        },
        {
          name: '高强度跑距离',
          type: 'bar',
          barMaxWidth: '30px',
          barGap: 0,
          // stack: 'typered',
          yAxisIndex: 1,
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          data: []
        },
        {
          name: '队伍人均高强度跑距离',
          type: 'line',
          barMaxWidth: '30px',
          symbolSize: 8,
          symbol: 'circle',
          // stack: 'typered',
          yAxisIndex: 1,
          data: []
        }
      ]
    },
    HR_TIME_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#6aa9e8', '#6aa9e8', '#ec6a86', '#ec6a86'],
      legend: {
        data: ['心率负荷', '队伍人均心率负荷', '身体负荷', '队伍人均身体负荷']
      },
      grid: {
        left: '3%',
        right: '3%',
        top: '120px',
        bottom: '50px',
        containLabel: true
      },
      // dataZoom: [
      //   {
      //     type: 'slider',
      //     show: true,
      //     start: 0,
      //     end: 100
      //   }
      // ],
      xAxis: [
        {
          type: 'category',
          data: ['0\'', '5\'', '10\'', '15\'', '20\'', '25\'', '30\'', '35\'', '40\'', '45\'', '中场休息', '45\'', '50\'', '55\'', '60\'', '65\'', '70\'', '75\'', '80\'', '85\''],
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '心率负荷',
          type: 'bar',
          barMaxWidth: '30px',
          // stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          data: []
        },
        {
          name: '队伍人均心率负荷',
          type: 'line',
          barMaxWidth: '30px',
          // stack: 'type',
          data: [34, 13, 34, 12, 56, 67, 89, 54, 32, 23, 15, 15, 34, 45, 24, 23, 15, 21, 56, 12]
        },
        {
          name: '身体负荷',
          type: 'bar',
          barMaxWidth: '30px',
          barGap: 0,
          // stack: 'typered',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          data: []
        },
        {
          name: '队伍人均身体负荷',
          type: 'line',
          barMaxWidth: '30px',
          symbolSize: 8,
          symbol: 'circle',
          // stack: 'typered',
          data: [20, 20, 34, 56, 20, 20, 20, 78, 90, 24, 35, 46, 12, 35, 64, 75, 20, 20, 20, 20]
        }
      ]
    },
    SPEED_SINGLE_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#6aa9e8', '#ec6a86'],
      legend: {
        data: ['队伍人均跑动距离', '队伍人均高强度跑距离']
      },
      grid: {
        left: '3%',
        right: '3%',
        top: '120px',
        bottom: '50px',
        containLabel: true
      },
      // dataZoom: [
      //   {
      //     type: 'slider',
      //     show: true,
      //     start: 0,
      //     end: 80
      //   }
      // ],
      xAxis: [
        {
          type: 'category',
          data: ['0\'', '5\'', '10\'', '15\'', '20\'', '25\'', '30\'', '35\'', '40\'', '45\'', '中场休息', '45\'', '50\'', '55\'', '60\'', '65\'', '70\'', '75\'', '80\'', '85\''],
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          boundaryGap: ['20%', '50%'],
          splitLine: {
            show: false
          },
          axisTick: {
            show: true
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '距离(m)',
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        },
        {
          type: 'value',
          name: '高强度跑距离(m)',
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '队伍人均跑动距离',
          type: 'bar',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          barMaxWidth: '30px',
          data: [34, 13, 34, 12, 56, 67, 89, 54, 32, 23, 15, 15, 34, 45, 24, 23, 15, 21, 56, 12]
        },
        {
          name: '队伍人均高强度跑距离',
          type: 'line',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          yAxisIndex: 1,
          barMaxWidth: '30px',
          symbolSize: 8,
          symbol: 'circle',
          data: [20, 20, 34, 56, 20, 20, 20, 78, 90, 24, 35, 46, 12, 35, 64, 75, 20, 20, 20, 20]
        }
      ]
    },
    SPEED_DOUBLE_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#ec6a86', '#6aa9e8', '#ec6a86', '#6aa9e8'],
      legend: {
        data: ['红队人均跑动距离', '蓝队人均跑动距离', '红队人均高强度跑距离', '蓝队人均高强度跑距离']
      },
      grid: {
        left: '3%',
        right: '3%',
        top: '120px',
        bottom: '50px',
        containLabel: true
      },
      // dataZoom: [
      //   {
      //     type: 'slider',
      //     show: true,
      //     start: 0,
      //     end: 80
      //   }
      // ],
      xAxis: [
        {
          type: 'category',
          data: ['0\'', '5\'', '10\'', '15\'', '20\'', '25\'', '30\'', '35\'', '40\'', '45\'', '中场休息', '45\'', '50\'', '55\'', '60\'', '65\'', '70\'', '75\'', '80\'', '85\''],
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          boundaryGap: ['20%', '50%'],
          splitLine: {
            show: false
          },
          axisTick: {
            show: true
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '距离(m)',
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        },
        {
          type: 'value',
          name: '高强度跑距离(m)',
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '红队人均跑动距离',
          type: 'bar',
          barGap: 0,
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          barMaxWidth: '30px',
          data: []
        },
        {
          name: '蓝队人均跑动距离',
          type: 'bar',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          barMaxWidth: '30px',
          data: []
        },
        {
          name: '红队人均高强度跑距离',
          type: 'line',
          // label: {
          //   normal: {
          //     show: true,
          //     position: 'top'
          //   }
          // },
          symbolSize: 8,
          symbol: 'circle',
          yAxisIndex: 1,
          data: [34, 13, 34, 12, 56, 67, 89, 54, 32, 23, 15, 15, 34, 45, 24, 23, 15, 21, 56, 12]
        },
        {
          name: '蓝队人均高强度跑距离',
          type: 'line',
          yAxisIndex: 1,
          // label: {
          //   normal: {
          //     show: true,
          //     position: 'top'
          //   }
          // },
          symbolSize: 8,
          symbol: 'circle',
          data: [20, 20, 34, 56, 20, 20, 20, 78, 90, 24, 35, 46, 12, 35, 64, 75, 20, 20, 20, 20]
        }
      ]
    },
    HR_SINGLE_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#6aa9e8', '#ec6a86'],
      legend: {
        data: ['队伍人均心率负荷', '队伍人均身体负荷']
      },
      grid: {
        left: '3%',
        right: '3%',
        top: '120px',
        bottom: '50px',
        containLabel: true
      },
      // dataZoom: [
      //   {
      //     type: 'slider',
      //     show: true,
      //     start: 0,
      //     end: 80
      //   }
      // ],
      xAxis: [
        {
          type: 'category',
          data: ['0\'', '5\'', '10\'', '15\'', '20\'', '25\'', '30\'', '35\'', '40\'', '45\'', '中场休息', '45\'', '50\'', '55\'', '60\'', '65\'', '70\'', '75\'', '80\'', '85\''],
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '队伍人均心率负荷',
          type: 'bar',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          barMaxWidth: '30px',
          stack: 'type',
          data: [34, 13, 34, 12, 56, 67, 89, 54, 32, 23, 15, 15, 34, 45, 24, 23, 15, 21, 56, 12]
        },
        {
          name: '队伍人均身体负荷',
          type: 'line',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          symbolSize: 8,
          symbol: 'circle',
          data: [20, 20, 34, 56, 20, 20, 20, 78, 90, 24, 35, 46, 12, 35, 64, 75, 20, 20, 20, 20]
        }
      ]
    },
    HR_DOUBLE_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#ec6a86', '#6aa9e8', '#ec6a86', '#6aa9e8'],
      legend: {
        data: ['红队人均心率负荷', '蓝队人均心率负荷', '红队人均身体负荷', '蓝队人均身体负荷']
      },
      grid: {
        left: '3%',
        right: '3%',
        top: '120px',
        bottom: '50px',
        containLabel: true
      },
      // dataZoom: [
      //   {
      //     type: 'slider',
      //     show: true,
      //     start: 0,
      //     end: 80
      //   }
      // ],
      xAxis: [
        {
          type: 'category',
          data: ['0\'', '5\'', '10\'', '15\'', '20\'', '25\'', '30\'', '35\'', '40\'', '45\'', '中场休息', '45\'', '50\'', '55\'', '60\'', '65\'', '70\'', '75\'', '80\'', '85\''],
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '红队人均心率负荷',
          type: 'bar',
          barGap: 0,
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          barMaxWidth: '30px',
          data: []
        },
        {
          name: '蓝队人均心率负荷',
          type: 'bar',
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          barMaxWidth: '30px',
          data: []
        },
        {
          name: '红队人均身体负荷',
          type: 'line',
          // label: {
          //   normal: {
          //     show: true,
          //     position: 'top'
          //   }
          // },
          symbolSize: 8,
          symbol: 'circle',
          barMaxWidth: '30px',
          data: [34, 13, 34, 12, 56, 67, 89, 54, 32, 23, 15, 15, 34, 45, 24, 23, 15, 21, 56, 12]
        },
        {
          name: '蓝队人均身体负荷',
          type: 'line',
          // label: {
          //   normal: {
          //     show: true,
          //     position: 'top'
          //   }
          // },
          symbolSize: 8,
          symbol: 'circle',
          data: [20, 20, 34, 56, 20, 20, 20, 78, 90, 24, 35, 46, 12, 35, 64, 75, 20, 20, 20, 20]
        }
      ]
    },
    SPEED_DIS_ECHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#74CB60', '#94C533', '#DEC547', '#EC9E51', '#F06044', '#CE0F3F'],
      legend: {
        itemGap: 20,
        data: ['走慢跑[0, 2.3)', '低速跑[2.3, 2.9)', '中速跑[2.9, 3.9)', '快速跑[3.9, 4.8)', '高速跑[4.8, 6.1)', '冲刺跑[6.1, --)']
      },
      grid: {
        left: '3%',
        right: '3%',
        top: '120px',
        bottom: '80px',
        containLabel: true
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          startValue: 0,
          endValue: 25
        }
      ],
      xAxis: [
        {
          type: 'category',
          data: ['李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰'],
          axisLabel: {
            textStyle: {
              color: '#666'
            },
            rotate: 45
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '%',
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '走慢跑[0, 2.3)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return val.data + '%'
              }
            }
          },
          data: []
        },
        {
          name: '低速跑[2.3, 2.9)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '中速跑[2.9, 3.9)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '快速跑[3.9, 4.8)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '高速跑[4.8, 6.1)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '冲刺跑[6.1, --)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        }
      ]
    },
    HRTIME_ECHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#74CB60', '#94C533', '#DEC547', '#EC9E51', '#F06044', '#CE0F3F'],
      legend: {
        data: ['区间1[0, 65%)', '区间2[66%, 71%)', '区间3[72%, 78%)', '区间4[79%, 85%)', '区间5[86%, 92%)', '区间6[92%, 100%)']
      },
      grid: {
        left: '3%',
        right: '3%',
        top: '120px',
        bottom: '80px',
        containLabel: true
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          startValue: 0,
          endValue: 25
        }
      ],
      xAxis: [
        {
          type: 'category',
          data: ['李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰'],
          axisLabel: {
            textStyle: {
              color: '#666'
            },
            rotate: 45
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '%',
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '区间1[0, 65%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '区间2[66%, 71%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '区间3[72%, 78%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '区间4[79%, 85%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '区间5[86%, 92%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '区间6[92%, 100%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        }
      ]
    },
    SPPEDRED_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#74CB60', '#94C533', '#DEC547', '#EC9E51', '#F06044', '#CE0F3F'],
      legend: {
        data: ['走慢跑[0, 2.3)', '低速跑[2.3, 2.9)', '中速跑[2.9, 3.9)', '快速跑[3.9, 4.8)', '高速跑[4.8, 6.1)', '冲刺跑[6.1, --)'],
        itemGap: 20
      },
      grid: {
        left: '3%',
        right: '3%',
        top: '120px',
        bottom: '80px',
        containLabel: true
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          startValue: 0,
          endValue: 25
        }
      ],
      xAxis: [
        {
          type: 'category',
          data: [],
          axisLabel: {
            textStyle: {
              color: '#666'
            },
            rotate: 45,
            interval: 0
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '%',
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '走慢跑[0, 2.3)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '低速跑[2.3, 2.9)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '中速跑[2.9, 3.9)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '快速跑[3.9, 4.8)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '高速跑[4.8, 6.1)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '冲刺跑[6.1, --)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        }
      ]
    },
    HRRED_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#74CB60', '#94C533', '#DEC547', '#EC9E51', '#F06044', '#CE0F3F'],
      legend: {
        data: ['区间一[0, 65%)', '区间二[66%, 71%)', '区间三[72%, 78%)', '区间四[79%, 85%)', '区间五[86%, 92%)', '区间六[92%, 100%)'],
        item: 5
      },
      grid: {
        left: '3%',
        right: '3%',
        top: '120px',
        bottom: '80px',
        containLabel: true
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          startValue: 0,
          endValue: 25
        }
      ],
      xAxis: [
        {
          type: 'category',
          data: [],
          axisLabel: {
            textStyle: {
              color: '#666'
            },
            rotate: 45,
            interval: 0
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '%',
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '区间一[0, 65%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '区间二[66%, 71%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '区间三[72%, 78%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '区间四[79%, 85%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '区间五[86%, 92%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '区间六[92%, 100%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        }
      ]
    },
    RANKDATAALL_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#6aa9e8', '#ec6a86', '#f9c20d'],
      legend: {
        data: ['跑动距离', '高强度跑距离', '最高速度']
      },
      grid: {
        left: '3%',
        right: '3%',
        top: '50px',
        bottom: '50px',
        containLabel: true
      },
      // dataZoom: [
      //   {
      //     type: 'slider',
      //     show: true,
      //     start: 0,
      //     end: 40
      //   }
      // ],
      xAxis: [
        {
          type: 'category',
          data: [],
          axisLabel: {
            textStyle: {
              color: '#666'
            },
            rotate: 45,
            interval: 0
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: 'm',
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        },
        {
          type: 'value',
          name: '高强度跑(m)',
          show: false,
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        },
        {
          type: 'value',
          name: 'm/s',
          show: false,
          position: 'right',
          offset: 50,
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          stack: 'typed',
          barMaxWidth: '30px',
          data: [100, 20, 70, 60, 90, 96, 100, 80, 80, 60, 100, 20, 70, 60, 90, 96, 100, 80, 80, 60]
        },
        {
          name: '高强度跑距离',
          type: 'bar',
          barMaxWidth: '30px',
          stack: 'typed',
          data: [100, 20, 70, 60, 90, 96, 100, 80, 80, 60, 100, 20, 70, 60, 90, 96, 100, 80, 80, 60]
        },
        {
          name: '最高速度',
          type: 'line',
          barMaxWidth: '30px',
          symbol: 'circle',
          data: [100, 20, 70, 60, 90, 96, 100, 80, 80, 60, 100, 20, 70, 60, 90, 96, 100, 80, 80, 60]
        }
      ]
    },
    BOTH_COMPARE: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {            // 坐标轴指示器，坐标轴触发有效
          type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
        }
      },
      legend: {
        data: ['红队人均', '红队全国平均', '蓝队人均', '蓝队全国平均', '红队全国最高', '蓝队全国最高', '红队近5次历史平均', '蓝队近5次历史平均'],
        show: false,
        selected: {}
      },
      grid: {
        left: 40,
        right: '4%',
        bottom: '3%',
        top: 10,
        containLabel: true
      },
      xAxis: {
        type: 'value',
        max: 110,
        min: -110,
        splitLine: {show: false},
        axisLabel: {show: false},
        axisLine: {show: false},
        axisTick: {show: false}
      },
      yAxis: {
        type: 'category',
        axisTick: {show: false},
        axisLine: {show: false},
        data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
        axisLabel: {
          margin: 50,
          textStyle: {
            fontWeight: 'bold',
            fontSize: 14
          }
        }
      },
      color: ['#ec6a86', '#6aa9e8'],
      series: [
        {
          name: '红队人均',
          type: 'bar',
          stack: 'datas',
          barWidth: 25,
          z: 10,
          label: {
            normal: {
              show: true,
              position: 'left'
            }
          },
          data: [-20, -32, -10, -34, -90, -30, -21]
        },
        {
          name: '红队全国平均',
          type: 'scatter',
          symbol: 'roundRect',
          hoverAnimation: false,
          silent: true,
          itemStyle: {
            normal: {
              color: '#96ce57'
            }
          },
          symbolSize: [3, 25],
          z: 20,
          data: [-30, -80, -50, -30, -30, -80, -50]
        },
        {
          name: '蓝队人均',
          type: 'bar',
          z: 10,
          stack: 'datas',
          barWidth: 25,
          label: {
            normal: {
              show: true,
              position: 'right',
              formatter: ''
            }
          },
          data: [32, 30, 41, 74, 90, 50, 42]
        },
        {
          name: '蓝队全国平均',
          type: 'scatter',
          symbol: 'roundRect',
          hoverAnimation: false,
          silent: true,
          itemStyle: {
            normal: {
              color: '#96ce57'
            }
          },
          symbolSize: [3, 25],
          z: 20,
          data: [30, 80, 50, 30, 30, 80, 50]
        },
        {
          name: '红队全国最高',
          type: 'scatter',
          symbol: 'roundRect',
          hoverAnimation: false,
          silent: true,
          itemStyle: {
            normal: {
              color: '#f9c20d'
            }
          },
          symbolSize: [3, 25],
          z: 20,
          data: [-100, -100, -100, -100, -100, -100, -100]
        },
        {
          name: '蓝队全国最高',
          type: 'scatter',
          symbol: 'roundRect',
          hoverAnimation: false,
          silent: true,
          itemStyle: {
            normal: {
              color: '#f9c20d'
            }
          },
          symbolSize: [3, 25],
          z: 20,
          data: [100, 100, 100, 100, 100, 100, 100]
        },
        {
          name: '红队近5次历史平均',
          type: 'scatter',
          symbol: 'roundRect',
          hoverAnimation: false,
          silent: true,
          itemStyle: {
            normal: {
              color: '#7D79E7'
            }
          },
          symbolSize: [3, 25],
          z: 20,
          data: [-30, -80, -50, -30, -30, -80, -50]
        },
        {
          name: '蓝队近5次历史平均',
          type: 'scatter',
          symbol: 'roundRect',
          hoverAnimation: false,
          silent: true,
          itemStyle: {
            normal: {
              color: '#7D79E7'
            }
          },
          symbolSize: [3, 25],
          z: 20,
          data: [-30, -80, -50, -30, -30, -80, -50]
        },
        {
          type: 'bar',
          barWidth: 25,
          stack: 'datas',
          silent: true,
          itemStyle: {
            normal: {
              color: '#ddd'
            }
          },
          tooltip: {
            show: false
          },
          // barGap: '-100%',
          data: [100, 100, 100, 100, 100, 100, 100]
        },
        {
          type: 'bar',
          barWidth: 25,
          stack: 'datas',
          silent: true,
          itemStyle: {
            normal: {
              color: '#ddd'
            }
          },
          tooltip: {
            show: false
          },
          // barGap: '-100%',
          data: [-100, -100, -100, -100, -100, -100, -100]
        }
      ]
    }
  },
  TRAIN_REPORT: {
    SPEEDS_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['训练全程']
      },
      color: ['#6aa9e8', '#96ce57', '#f9c20d'],
      grid: {
        left: '40px',
        right: '3%',
        top: '120px',
        bottom: '50px',
        containLabel: true
      },
      xAxis: [
        {
          type: 'category',
          data: ['走慢跑 [0, 2.3)', '低速跑 [2.3, 2.9)', '中速跑 [2.9, 3.9)', '快速跑 [3.9, 4.8)', '高速跑 [4.8, 6.1)', '冲刺跑 [6.1, --)'].map(k => {
            return k.split(' ').join('\n')
          }),
          axisLabel: {
            textStyle: {
              color: '#333'
            },
            interval: 0
          },
          splitLine: {
            show: true
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '距离(m)',
          nameTextStyle: {
            color: '#333'
          },
          axisLabel: {
            textStyle: {
              color: '#333'
            }
          },
          nameLocation: 'middle',
          nameGap: 45,
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '训练全程',
          type: 'bar',
          barMaxWidth: '30px',
          data: [210, 230, 435, 435, 563, 574],
          label: {
            normal: {
              show: true,
              position: 'top',
              formatter: function (val) {
                return val.data + ' (20%)'
              }
            }
          }
        }
        // {
        //   name: '训练单元1',
        //   type: 'line',
        //   symbol: 'circle',
        //   data: [230, 240, 477, 422, 534, 524]
        // },
        // {
        //   name: '训练单元2',
        //   type: 'line',
        //   symbol: 'circle',
        //   data: [240, 220, 423, 443, 512, 500]
        // }
      ]
    },
    HRTIMES_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['训练全程', '训练单元1', '训练单元2']
      },
      color: ['#6aa9e8', '#96ce57', '#f9c20d'],
      grid: {
        left: '45px',
        right: '3%',
        top: '120px',
        bottom: '50px',
        containLabel: true
      },
      xAxis: [
        {
          type: 'category',
          data: ['区间1  [0,65%)', '区间2  [66%,71%)', '区间3  [72%,78%)', '区间4  [79%,85%)', '区间5  [86%,92%)', '区间6  [93%,100%)'].map(k => {
            return k.split('  ').join('\n')
          }),
          axisLabel: {
            textStyle: {
              color: '#333'
            },
            interval: 0
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '时间(min)',
          nameTextStyle: {
            color: '#333'
          },
          nameLocation: 'middle',
          nameGap: 45,
          axisLabel: {
            textStyle: {
              color: '#393939'
            }
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '训练全程',
          type: 'bar',
          barMaxWidth: '30px',
          data: [210, 230, 435, 435, 563, 574],
          label: {
            normal: {
              show: true,
              position: 'top',
              formatter: function (val) {
                return val.data + ' (20%)'
              }
            }
          }
        },
        {
          name: '训练单元1',
          type: 'line',
          symbol: 'circle',
          data: [230, 240, 477, 422, 534, 524]
        },
        {
          name: '训练单元2',
          type: 'line',
          symbol: 'circle',
          data: [240, 220, 423, 443, 512, 500]
        }
      ]
    },
    RANKDATA_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#6aa9e8', '#ec6a86', '#f9c20d'],
      legend: {
        data: ['跑动距离', '高强度跑距离', '最高速度'],
        itemGap: 15
      },
      grid: {
        left: '3%',
        right: '3%',
        top: '120px',
        bottom: '65px',
        containLabel: true
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          startValue: 0,
          endValue: 12
        }
      ],
      xAxis: [
        {
          type: 'category',
          data: ['李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰'],
          axisLabel: {
            textStyle: {
              color: '#666'
            },
            rotate: 45
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: 'm',
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        },
        {
          type: 'value',
          name: '高强度跑(m)',
          show: false,
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        },
        {
          type: 'value',
          name: 'm/s',
          show: false,
          position: 'right',
          offset: 50,
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          barMaxWidth: '30px',
          data: [100, 20, 70, 60, 90, 96, 100, 80, 80, 60, 100, 20, 70, 60, 90, 96, 100, 80, 80, 60]
        },
        {
          name: '高强度跑距离',
          type: 'bar',
          barMaxWidth: '30px',
          data: [100, 20, 70, 60, 90, 96, 100, 80, 80, 60, 100, 20, 70, 60, 90, 96, 100, 80, 80, 60]
        },
        {
          name: '最高速度',
          type: 'line',
          barMaxWidth: '30px',
          symbol: 'circle',
          data: [100, 20, 70, 60, 90, 96, 100, 80, 80, 60, 100, 20, 70, 60, 90, 96, 100, 80, 80, 60]
        }
      ]
    },
    SPEED_DISTENCE_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#74CB60', '#94C533', '#DEC547', '#EC9E51', '#F06044', '#CE0F3F'],
      legend: {
        data: ['走慢跑[0, 2.3)', '低速跑[2.3, 2.9)', '中速跑[2.9, 3.9)', '快速跑[3.9, 4.8)', '高速跑[4.8, 6.1)', '冲刺跑[6.1, --)'],
        itemGap: 20
      },
      grid: {
        left: '3%',
        right: '3%',
        top: '120px',
        bottom: '80px',
        containLabel: true
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          startValue: 0,
          endValue: 25
        }
      ],
      xAxis: [
        {
          type: 'category',
          data: ['李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰'],
          axisLabel: {
            textStyle: {
              color: '#666'
            },
            rotate: 45
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '%',
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '走慢跑[0, 2.3)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '低速跑[2.3, 2.9)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '中速跑[2.9, 3.9)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '快速跑[3.9, 4.8)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '高速跑[4.8, 6.1)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '冲刺跑[6.1, --)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        }
      ]
    },
    HR_TIME_CHART: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#74CB60', '#94C533', '#DEC547', '#EC9E51', '#F06044', '#CE0F3F'],
      legend: {
        data: ['[0, 65%)', '[66%, 71%)', '[72%, 78%)', '[79%, 85%)', '[86%, 92%)', '[92%, 100%)'],
        itemGap: 5
      },
      grid: {
        left: '3%',
        right: '3%',
        top: '120px',
        bottom: '80px',
        containLabel: true
      },
      dataZoom: [
        {
          type: 'slider',
          show: true,
          startValue: 0,
          endValue: 25
        }
      ],
      xAxis: [
        {
          type: 'category',
          data: ['李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰', '李云杰'],
          axisLabel: {
            textStyle: {
              color: '#666'
            },
            rotate: 45
          },
          splitLine: {
            show: false
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      yAxis: [
        {
          type: 'value',
          name: '%',
          nameTextStyle: {
            color: '#666'
          },
          axisLabel: {
            textStyle: {
              color: '#666'
            }
          },
          splitLine: {
            show: true,
            lineStyle: {
              color: ['#e0e0e0']
            }
          },
          axisTick: {
            show: false
          },
          axisLine: {
            lineStyle: {
              color: ['#e0e0e0']
            }
          }
        }
      ],
      series: [
        {
          name: '[0, 65%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '[66%, 71%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '[72%, 78%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '[79%, 85%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '[86%, 92%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        },
        {
          name: '[92%, 100%)',
          type: 'bar',
          barMaxWidth: '35px',
          stack: 'type',
          label: {
            normal: {
              show: true,
              position: 'inside',
              formatter: function (val) {
                return (val.data > 6 ? (val.data + '%') : '')
              }
            }
          },
          data: []
        }
      ]
    }
  }
}
export default PERSON
