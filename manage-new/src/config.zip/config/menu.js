/**
 * Created by dongshuyue on 2016/10/26.
 */
const MENU = {
  HEADER_MENU: [
    {name: '首页', path: '/index/home'},
    {name: '测评', path: '/index/test/test_overview'},
    {name: '比赛数据', path: '/index/match/match_overview'},
    {name: '训练数据', path: '/index/train/train_scan'},
    // {name: '成长记录', path: '/index/growth'},
    {name: '排行榜', path: '/index/rank'},
    {name: '团队管理', path: '/index/team'},
    {name: '人员管理', path: '/index/persons'}
    // {name: '综合评价', path: '/index/evaluate'}
  ],
  MANAGE_MENU: [
    // {name: '营区管理', path: '/index/team'},
    // {name: '人员管理', path: '/index/persons'},
    {name: '后台管理', path: 'http://www.sportsdatas.cn/admin'},
    {name: '个人设置', path: '/index/setup'}
  ],
  MATCH_PROJECT: [
    {name: '平均心率', value: '1'},
    {name: '平均心率强度', value: '2'},
    {name: '心率恢复率', value: '3'},
    {name: '身体负荷', value: '4'},
    {name: '心率负荷', value: '5'},
    {name: '跑动距离', value: '6'},
    {name: '高强度跑距离', value: '7'}
  ],
  VIEW_BTN: {
    NATION: [
      {name: '小学', value: 1},
      {name: '初中', value: 2},
      {name: '高中', value: 3}
    ]
  }
}
export default MENU
