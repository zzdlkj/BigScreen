const SEVERS = {
  api: { // 接口
    // 测试
    // 'localhost:8080': 'http://llcloud.sportsdatas.cn/tchcloud',
    'localhost:8080': 'http://cloudtest.sportsdatas.cn/web',
    // 'localhost:8080': 'http://llcloud.sportsdatas.cn/web',
    'mttest.sportsdatas.cn': 'http://cloudtest.sportsdatas.cn/web',
    'petest.sportsdatas.cn': 'http://cloudtest.sportsdatas.cn/web',
    'edutest.sportsdatas.cn': 'http://cloudtest.sportsdatas.cn/web',
    // 正式服务器
    'mt.sportsdatas.cn': 'http://cloud.sportsdatas.cn/web',
    'pe.sportsdatas.cn': 'http://cloud.sportsdatas.cn/web',
    'edu.sportsdatas.cn': 'http://cloud.sportsdatas.cn/web',
    'hd.sportsdatas.cn': 'http://cloud.sportsdatas.cn/web',
    'cffc.sportsdatas.cn': 'http://cloud.sportsdatas.cn/web',
    'cfa.sportsdatas.cn': 'http://cloud.sportsdatas.cn/web',
    'ztx.sportsdatas.cn': 'http://cloud.sportsdatas.cn/web',
    'cssf.sportsdatas.cn': 'http://cloud.sportsdatas.cn/web',
    'gdfc.sportsdatas.cn': 'http://cloud.sportsdatas.cn/web',
    '192.168.26.200': 'http://192.168.26.200/web'
  },
  report: {
    // 测试
    'localhost:8080': 'http://testwap.sportsdatas.cn',
    'mttest.sportsdatas.cn': 'http://testwap.sportsdatas.cn',
    'petest.sportsdatas.cn': 'http://testwap.sportsdatas.cn',
    'edutest.sportsdatas.cn': 'http://testwap.sportsdatas.cn',
    // 正式服务器
    'mt.sportsdatas.cn': 'http://wap.sportsdatas.cn',
    'pe.sportsdatas.cn': 'http://wap.sportsdatas.cn',
    'edu.sportsdatas.cn': 'http://wap.sportsdatas.cn',
    'hd.sportsdatas.cn': 'http://wap.sportsdatas.cn',
    'cffc.sportsdatas.cn': 'http://wap.sportsdatas.cn',
    'cfa.sportsdatas.cn': 'http://wap.sportsdatas.cn',
    'ztx.sportsdatas.cn': 'http://wap.sportsdatas.cn',
    'cssf.sportsdatas.cn': 'http://wap.sportsdatas.cn',
    'gdfc.sportsdatas.cn': 'http://wap.sportsdatas.cn',
    '192.168.26.200': 'http://wap.sportsdatas.cn'
  },
  // login: {
  //   // 测试
  //   'localhost:8080': 'Login',
  //   // 'localhost:8080': 'Logins',
  //   'mttest.sportsdatas.cn': 'Login',
  //   'petest.sportsdatas.cn': 'Logins',
  //   // 正式服务器
  //   'mt.sportsdatas.cn': 'Login',
  //   'pe.sportsdatas.cn': 'Logins',
  //   'hd.sportsdatas.cn': 'Login',
  //   'cffc.sportsdatas.cn': 'Login',
  //   'cfa.sportsdatas.cn': 'Login',
  //   'ztx.sportsdatas.cn': 'Login',
  //   'cssf.sportsdatas.cn': 'Login'
  // },
  logingo: {
    // 测试
    // 'localhost:8080': '/admin/nav',
    // 'localhost:8080': '/admin/index',
    'localhost:8080': '/edu/index',
    'mttest.sportsdatas.cn': '/admin/nav',
    'petest.sportsdatas.cn': '/admin/index',
    'edutest.sportsdatas.cn': '/edu/index',
    // 正式服务器
    'mt.sportsdatas.cn': '/admin/nav',
    'pe.sportsdatas.cn': '/admin/index',
    'edu.sportsdatas.cn': '/edu/index',
    'hd.sportsdatas.cn': '/admin/nav',
    'cffc.sportsdatas.cn': '/admin/nav',
    'cfa.sportsdatas.cn': '/admin/nav',
    'ztx.sportsdatas.cn': '/admin/nav',
    'cssf.sportsdatas.cn': '/admin/nav',
    'ali.sportsdatas.cn': '/admin/index',
    'gdfc.sportsdatas.cn': '/admin/nav'
  }
}
export default SEVERS
