/**
 * Created by dongshuyue on 2016/11/3.
 */
const GROW = {
  PERSON_DETAIL: {
    BASIC_RADAR: {
      color: ['#ce6763', '#00ceb8', '#f5c022'],
      radar: {
        indicator: [
          {text: '高强度距离占比'},
          {text: '平均心率'},
          {text: '跑动距离'}
        ],
        center: ['50%', '50%'],
        radius: '25%',
        startAngle: 90,
        shape: 'rect',
        name: {
          textStyle: {
            fontSize: '12',
            color: '#666666'
          }
        }
      },
      series: [
        {
          type: 'radar',
          data: [
            {
              name: '当前水平',
              value: [],
              label: {
                normal: {
                  show: true,
                  position: [-20, 15]
                }
              }
            }
          ]
        }
      ]
    },
    COUNTS_H: ['参赛', '训练', '测评'],
    HEALTH_H: ['身高', '体重', 'BMI', '肺活量', '胸围', '臂展', '基本心率', '最大心率', '心率功能指数'],
    SPECIAL_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      grid: {
        bottom: '22%'
      },
      legend: {
        data: ['跑动距离']
      },
      color: ['#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: ['01月', '02月', '03月', '04月', '05月', '06月', '07月', '08月', '09月', '10月', '11月', '12月'],
        axisLabel: {
          interval: 0,
          rotate: 45,
          formatter: function (params) {
            if (!params) return ''
            var newParamsName = ''
            var paramsNameNumber = params.length
            var provideNumber = 8
            var rowNumber = Math.ceil(paramsNameNumber / provideNumber)
            if (paramsNameNumber > provideNumber) {
              for (var p = 0; p < rowNumber; p++) {
                var tempStr = ''
                var start = p * provideNumber
                var end = start + provideNumber
                if (p === rowNumber - 1) {
                  tempStr = params.substring(start, paramsNameNumber)
                } else {
                  tempStr = params.substring(start, end) + '\n'
                }
                newParamsName += tempStr
              }
            } else {
              newParamsName = params
            }
            return newParamsName
          }
        }
      },
      yAxis: {
        type: 'value',
        name: '距离(m)',
        min: 0,
        splitLine: {
          show: false
        }
      },
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: [],
          markLine: {
            data: [
              {
                yAxis: 4000,
                name: '全国平均',
                label: {
                  normal: {
                    show: false
                  }
                },
                lineStyle: {
                  normal: {
                    color: '#d48265'
                  }
                }
              }
            ]
          }
        }
      ]
    },
    SPECIAL_ECH: [
      {
        legend: ['跑动距离'],
        yAxis: {
          type: 'value',
          name: '距离(m)',
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '跑动距离'
      },
      {
        legend: ['高强度跑占比'],
        yAxis: {
          type: 'value',
          name: '占比(%)',
          max: 100,
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '高强度跑占比'
      },
      {
        legend: ['平均心率'],
        yAxis: {
          type: 'value',
          name: 'bpm',
          min: 0,
          // max: 250,
          splitLine: {
            show: false
          }
        },
        series: '平均心率'
      }
    ],
    TRAIN_ECH: [
      {
        legend: ['跑动距离'],
        yAxis: {
          type: 'value',
          name: '距离(m)',
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '跑动距离'
      },
      {
        legend: ['高强度跑占比'],
        yAxis: {
          type: 'value',
          name: '占比(%)',
          max: 100,
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '高强度跑占比'
      },
      {
        legend: ['冲刺跑占比'],
        yAxis: {
          type: 'value',
          name: '占比(%)',
          max: 100,
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '冲刺跑占比'
      },
      {
        legend: ['平均心率'],
        yAxis: {
          type: 'value',
          name: 'bpm',
          min: 0,
          // max: 250,
          splitLine: {
            show: false
          }
        },
        series: '平均心率'
      }
    ],
    MATCH_ECH: [
      {
        legend: ['跑动距离'],
        yAxis: {
          type: 'value',
          name: '距离(m)',
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '跑动距离'
      },
      {
        legend: ['高速跑距离'],
        yAxis: {
          type: 'value',
          name: '距离(m)',
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '高速跑距离'
      },
      {
        legend: ['高强度跑占比'],
        yAxis: {
          type: 'value',
          name: '占比(%)',
          max: 100,
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '高强度跑占比'
      },
      {
        legend: ['冲刺跑距离'],
        yAxis: {
          type: 'value',
          name: '距离(m)',
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '冲刺跑距离'
      },
      {
        legend: ['冲刺跑占比'],
        yAxis: {
          type: 'value',
          name: '占比(%)',
          max: 100,
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '冲刺跑占比'
      },
      {
        legend: ['最大速度'],
        yAxis: {
          type: 'value',
          name: '速度(m/s)',
          // max: 100,
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '最大速度'
      },
      {
        legend: ['心率负荷'],
        yAxis: {
          type: 'value',
          name: 'trimp',
          min: 0,
          // max: 250,
          splitLine: {
            show: false
          }
        },
        series: '心率负荷'
      },
      {
        legend: ['身体负荷'],
        yAxis: {
          type: 'value',
          name: 'trimp',
          min: 0,
          // max: 250,
          splitLine: {
            show: false
          }
        },
        series: '身体负荷'
      }
    ],
    MATCH_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      grid: {
        bottom: '22%'
      },
      legend: {
        data: ['跑动距离', '全国平均']
      },
      color: ['#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: ['01月', '02月', '03月', '04月', '05月', '06月', '07月', '08月', '09月', '10月', '11月', '12月'],
        axisLabel: {
          interval: 0,
          rotate: 45,
          formatter: function (params) {
            if (!params) return ''
            var newParamsName = ''
            var paramsNameNumber = params.length
            var provideNumber = 8
            var rowNumber = Math.ceil(paramsNameNumber / provideNumber)
            if (paramsNameNumber > provideNumber) {
              for (var p = 0; p < rowNumber; p++) {
                var tempStr = ''
                var start = p * provideNumber
                var end = start + provideNumber
                if (p === rowNumber - 1) {
                  tempStr = params.substring(start, paramsNameNumber)
                } else {
                  tempStr = params.substring(start, end) + '\n'
                }
                newParamsName += tempStr
              }
            } else {
              newParamsName = params
            }
            return newParamsName
          }
        }
      },
      yAxis: [
        {
          type: 'value',
          name: '距离(m)',
          min: 0,
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: [],
          markLine: {
            data: [
              {
                yAxis: 4000,
                name: '全国平均',
                label: {
                  normal: {
                    show: false
                  }
                },
                lineStyle: {
                  normal: {
                    color: '#d48265'
                  }
                }
              }
            ]
          }
        }
      ]
    },
    TRAIN_ECHARTS: {
      legend: {
        data: ['跑动距离']
      },
      color: ['#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: ['01月', '02月', '03月', '04月', '05月', '06月', '07月', '08月', '09月', '10月', '11月', '12月']
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      yAxis: [
        {
          type: 'value',
          name: '距离(m)',
          min: 0,
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: [],
          markLine: {
            data: [
              {
                yAxis: 4000,
                name: '全国平均',
                label: {
                  normal: {
                    show: false
                  }
                },
                lineStyle: {
                  normal: {
                    color: '#d48265'
                  }
                }
              }
            ]
          }
        }
      ]
    },
    GAMES_ECHARTS: {
      tooltip: {
        formatter: '{a0}<br>{b0}'
      },
      legend: {
        orient: 'vertical',
        left: 'right',
        data: []
      },
      color: ['#f9c30c', '#545454', '#61a2aa', '#D48265', '#91C7AE'],
      series: [
        {
          name: '比赛类型场次时长',
          type: 'pie',
          radius: '60%',
          center: ['40%', '45%'],
          label: {
            normal: {
              show: false
            },
            emphasis: {
              show: true
            }
          },
          data: [0]
        }
      ]
    },
    RUN_ECHARTS: {
      tooltip: {
        formatter: '{a0}<br>{b0}'
      },
      legend: {
        orient: 'vertical',
        left: 'right',
        data: ['场均冲刺跑-200m-25%', '场均高速跑-600m-75%']
      },
      color: ['#f9c30c', '#545454', '#61a2aa', '#D48265', '#91C7AE'],
      series: [
        {
          name: '场均跑动距离',
          type: 'pie',
          radius: '60%',
          center: ['40%', '45%'],
          label: {
            normal: {
              show: false
            },
            emphasis: {
              show: true
            }
          },
          data: [
            {value: 200, name: '场均冲刺跑-200m-25%'},
            {value: 600, name: '场均高速跑-600m-75%'}
          ]
        }
      ]
    },
    PERSON_ECHARTS: {
      title: {
        text: '身高',
        left: 'center',
        textStyle: {
          fontSize: 12
        }
      },
      tooltip: {
        trigger: 'item'
      },
      legend: {
        left: 'left'
      },
      xAxis: {
        type: 'category',
        name: 'x',
        axisLabel: {
          interval: 0,
          show: false
        },
        data: [],
        axisTick: {
          show: false
        },
        axisLine: {
          show: false
        }
      },
      grid: {
        width: '100%',
        left: '0',
        right: '0%',
        bottom: '0%',
        containLabel: false
      },
      yAxis: {
        type: 'value',
        splitLine: {
          show: false
        },
        axisLine: {
          show: false
        },
        axisLabel: {
          show: false
        },
        axisTick: {
          show: false
        }
      },
      series: [
        {
          name: '身高',
          type: 'line',
          symbolSize: 10,
          data: []
        }
      ]
    }
  },
  TEAM_DETAIL: {
    SPECIAL_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      grid: {
        bottom: '22%'
      },
      legend: {
        data: ['跑动距离']
      },
      color: ['#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: ['01月', '02月', '03月', '04月', '05月', '06月', '07月', '08月', '09月', '10月', '11月', '12月'],
        axisLabel: {
          interval: 0,
          rotate: 45,
          formatter: function (params) {
            if (!params) return ''
            var newParamsName = ''
            var paramsNameNumber = params.length
            var provideNumber = 8
            var rowNumber = Math.ceil(paramsNameNumber / provideNumber)
            if (paramsNameNumber > provideNumber) {
              for (var p = 0; p < rowNumber; p++) {
                var tempStr = ''
                var start = p * provideNumber
                var end = start + provideNumber
                if (p === rowNumber - 1) {
                  tempStr = params.substring(start, paramsNameNumber)
                } else {
                  tempStr = params.substring(start, end) + '\n'
                }
                newParamsName += tempStr
              }
            } else {
              newParamsName = params
            }
            return newParamsName
          }
        }
      },
      yAxis: {
        type: 'value',
        name: '距离(km)',
        min: 0,
        splitLine: {
          show: false
        }
      },
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: [],
          markLine: {
            data: [
              {
                yAxis: 4000,
                name: '全国平均',
                label: {
                  normal: {
                    show: false
                  }
                },
                lineStyle: {
                  normal: {
                    color: '#d48265'
                  }
                }
              }
            ]
          }
        }
      ]
    },
    SPECIAL_ECH: [
      {
        legend: ['跑动距离'],
        yAxis: {
          type: 'value',
          name: '距离(km)',
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '跑动距离'
      },
      {
        legend: ['高强度跑占比'],
        yAxis: {
          type: 'value',
          name: '占比(%)',
          max: 100,
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '高强度跑占比'
      },
      {
        legend: ['平均心率'],
        yAxis: {
          type: 'value',
          name: 'bpm',
          min: 0,
          // max: 250,
          splitLine: {
            show: false
          }
        },
        series: '平均心率'
      }
    ],
    TRAIN_ECH: [
      {
        legend: ['跑动距离'],
        yAxis: {
          type: 'value',
          name: '距离(km)',
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '跑动距离'
      },
      {
        legend: ['高强度跑占比'],
        yAxis: {
          type: 'value',
          name: '占比(%)',
          max: 100,
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '高强度跑占比'
      },
      {
        legend: ['冲刺跑占比'],
        yAxis: {
          type: 'value',
          name: '占比(%)',
          max: 100,
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '冲刺跑占比'
      },
      {
        legend: ['平均心率'],
        yAxis: {
          type: 'value',
          name: 'bpm',
          min: 0,
          // max: 250,
          splitLine: {
            show: false
          }
        },
        series: '平均心率'
      }
    ],
    MATCH_ECH: [
      {
        legend: ['跑动距离'],
        yAxis: {
          type: 'value',
          name: '距离(km)',
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '跑动距离'
      },
      {
        legend: ['高速跑距离'],
        yAxis: {
          type: 'value',
          name: '距离(m)',
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '高速跑距离'
      },
      {
        legend: ['高强度跑占比'],
        yAxis: {
          type: 'value',
          name: '占比(%)',
          max: 100,
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '高强度跑占比'
      },
      {
        legend: ['冲刺跑距离'],
        yAxis: {
          type: 'value',
          name: '距离(m)',
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '冲刺跑距离'
      },
      {
        legend: ['冲刺跑占比'],
        yAxis: {
          type: 'value',
          name: '占比(%)',
          max: 100,
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '冲刺跑占比'
      },
      {
        legend: ['最大速度'],
        yAxis: {
          type: 'value',
          name: '速度(m/s)',
          // max: 100,
          min: 0,
          splitLine: {
            show: false
          }
        },
        series: '最大速度'
      },
      {
        legend: ['心率负荷'],
        yAxis: {
          type: 'value',
          name: 'trimp',
          min: 0,
          // max: 250,
          splitLine: {
            show: false
          }
        },
        series: '心率负荷'
      },
      {
        legend: ['身体负荷'],
        yAxis: {
          type: 'value',
          name: 'trimp',
          min: 0,
          // max: 250,
          splitLine: {
            show: false
          }
        },
        series: '身体负荷'
      }
    ],
    MATCH_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      grid: {
        bottom: '22%'
      },
      legend: {
        data: ['跑动距离', '全国平均']
      },
      color: ['#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: ['01月', '02月', '03月', '04月', '05月', '06月', '07月', '08月', '09月', '10月', '11月', '12月'],
        axisLabel: {
          interval: 0,
          rotate: 45,
          formatter: function (params) {
            if (!params) return ''
            var newParamsName = ''
            var paramsNameNumber = params.length
            var provideNumber = 8
            var rowNumber = Math.ceil(paramsNameNumber / provideNumber)
            if (paramsNameNumber > provideNumber) {
              for (var p = 0; p < rowNumber; p++) {
                var tempStr = ''
                var start = p * provideNumber
                var end = start + provideNumber
                if (p === rowNumber - 1) {
                  tempStr = params.substring(start, paramsNameNumber)
                } else {
                  tempStr = params.substring(start, end) + '\n'
                }
                newParamsName += tempStr
              }
            } else {
              newParamsName = params
            }
            return newParamsName
          }
        }
      },
      yAxis: [
        {
          type: 'value',
          name: '距离(km)',
          min: 0,
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: [],
          markLine: {
            data: [
              {
                yAxis: 4000,
                name: '全国平均',
                label: {
                  normal: {
                    show: false
                  }
                },
                lineStyle: {
                  normal: {
                    color: '#d48265'
                  }
                }
              }
            ]
          }
        }
      ]
    },
    TRAIN_ECHARTS: {
      legend: {
        data: ['跑动距离']
      },
      color: ['#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        axisLabel: {
          interval: 0,
          rotate: 45
        },
        data: ['01月', '02月', '03月', '04月', '05月', '06月', '07月', '08月', '09月', '10月', '11月', '12月']
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      yAxis: [
        {
          type: 'value',
          name: '距离(km)',
          min: 0,
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: [],
          markLine: {
            data: [
              {
                yAxis: 4000,
                name: '全国平均',
                label: {
                  normal: {
                    show: false
                  }
                },
                lineStyle: {
                  normal: {
                    color: '#d48265'
                  }
                }
              }
            ]
          }
        }
      ]
    }
  }
}
export default GROW
