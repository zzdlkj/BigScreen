/**
 * Created by dongshuyue on 2016/10/28.
 */
const TEST = {
  // 专项报告数据开始
  TEST_REPORT: {
    DISTANCE_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: [],
        top: '3%'
      },
      grid: {
        left: '15%'
      },
      color: ['#2f4554', '#e93232', '#d48265'],
      yAxis: {
        type: 'category',
        data: []
      },
      xAxis: [
        {
          type: 'value',
          min: 0,
          name: 'm',
          nameGap: 3,
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '',
          type: 'bar',
          barMaxWidth: 40,
          data: [],
          markLine: {
            data: [
              {
                xAxis: 40,
                name: '全组平均',
                label: {
                  normal: {
                    show: false
                  },
                  emphasis: {
                    position: 'start',
                    show: true
                  }
                }
              },
              {
                xAxis: 50,
                name: '全国平均',
                label: {
                  normal: {
                    show: false
                  },
                  emphasis: {
                    position: 'start',
                    show: true
                  }
                },
                lineStyle: {
                  normal: {
                    color: '#d48265'
                  }
                }
              }
            ]
          }
        }
      ]
    },
    HR_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['平均心率'],
        top: '3%'
      },
      grid: {
        left: '1%'
      },
      color: ['#d0675e', '#e93232', '#d48265'],
      yAxis: {
        type: 'category',
        axisLabel: {
          show: false
        },
        data: []
      },
      xAxis: {
        type: 'value',
        min: 0,
        name: 'bpm',
        nameGap: 3,
        splitLine: {
          show: false
        }
      },
      series: [
        {
          name: '平均心率',
          type: 'bar',
          data: [],
          barMaxWidth: 40,
          markLine: {
            data: [
              {
                xAxis: 40,
                name: '全组平均',
                label: {
                  normal: {
                    show: false
                  }
                }
              },
              {
                xAxis: 50,
                name: '全国平均',
                label: {
                  normal: {
                    show: false
                  }
                },
                lineStyle: {
                  normal: {
                    color: '#d48265'
                  }
                }
              }
            ]
          }
        }
      ]
    },
    HIGH_RATE_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['高强度跑距离'],
        top: '3%'
      },
      grid: {
        left: '1%'
      },
      color: ['#61a0a8', '#e93232', '#d48265'],
      yAxis: {
        type: 'category',
        axisLabel: {
          show: false
        },
        data: ['张一', '张二', '张三', '张思', '张武', '张六']
      },
      xAxis: [
        {
          type: 'value',
          min: 0,
          name: 'm',
          nameGap: 3,
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '高强度跑距离',
          type: 'bar',
          barMaxWidth: 40,
          data: [],
          markLine: {
            data: [
              {
                xAxis: 40,
                name: '全组平均',
                label: {
                  normal: {
                    show: false
                  }
                }
              },
              {
                xAxis: 50,
                name: '全国平均',
                label: {
                  normal: {
                    show: false
                  }
                },
                lineStyle: {
                  normal: {
                    color: '#d48265'
                  }
                }
              }
            ]
          }
        }
      ]
    },
    MAX_SPEED_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['最大速度'],
        top: '3%'
      },
      color: ['#2f4554', '#e93232', '#d48265'],
      yAxis: {
        type: 'category',
        data: ['张一', '张二', '张三', '张思', '张武', '张六']
      },
      xAxis: [
        {
          type: 'value',
          min: 0,
          name: '速度',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '最大速度',
          type: 'bar',
          data: [],
          markLine: {
            data: [
              {type: 'average', name: '人员平均'}
            ]
          }
        }
      ]
    }
  },
  // 专项数据数据结束
  // 专项测评概览开始
  TEST_VIEW: {
    VIEW_ECHARTS: {
      legend: {
        data: ['平均跑动距离', '平均高强度跑距离占比', '高于平均心率人数占比']
        // selected: {
        //   '场均高于平均心率人数占比': false
        // }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#61a0a8', '#c23531', '#d48265'],
      grid: {
        left: '4%',
        right: '5%',
        bottom: '22%'
      },
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          rotate: 45,
          interval: 0,
          formatter: function (params) {
            if (!params) return ''
            var newParamsName = ''
            var paramsNameNumber = params.length
            var provideNumber = 8
            var rowNumber = Math.ceil(paramsNameNumber / provideNumber)
            if (paramsNameNumber > provideNumber) {
              for (var p = 0; p < rowNumber; p++) {
                var tempStr = ''
                var start = p * provideNumber
                var end = start + provideNumber
                if (p === rowNumber - 1) {
                  tempStr = params.substring(start, paramsNameNumber)
                } else {
                  tempStr = params.substring(start, end) + '\n'
                }
                newParamsName += tempStr
              }
            } else {
              newParamsName = params
            }
            return newParamsName
          }
        }
      },
      yAxis: [
        {
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        },
        {
          min: 0,
          max: 100,
          name: '占比(%)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '平均跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: [],
          markLine: {
            data: [
              {type: 'average', name: '平均值'}
            ],
            label: {
              normal: {
                show: false
              }
            }
          }
        },
        {
          name: '平均高强度跑距离占比',
          type: 'line',
          yAxisIndex: 1,
          symbolSize: 8,
          data: []
        },
        {
          name: '高于平均心率人数占比',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: []
        }
      ]
    },
    TREND_ECHARTS: {
      legend: {
        data: ['平均跑动距离', '平均高强度跑距离占比', '高于平均心率人数占比']
        // selected: {
        //   '场均高于平均心率人数占比': false
        // }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#61a0a8', '#c23531', '#d48265'],
      grid: {
        left: '4%',
        right: '5%'
      },
      xAxis: {
        type: 'category',
        name: '月',
        data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
      },
      yAxis: [
        {
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        },
        {
          min: 0,
          max: 100,
          name: '占比(%)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '平均跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: [],
          markLine: {
            data: [
              {type: 'average', name: '平均值'}
            ],
            label: {
              normal: {
                show: false
              }
            }
          }
        },
        {
          name: '平均高强度跑距离占比',
          type: 'line',
          yAxisIndex: 1,
          symbolSize: 8,
          data: []
        },
        {
          name: '高于平均心率人数占比',
          type: 'line',
          yAxisIndex: 1,
          symbolSize: 8,
          data: []
        }
      ]
    },
    TOTAL_PIE: {
      tooltip: {
        formatter: '{a0}<br>{b0}: {c0}'
      },
      legend: {
        orient: 'vertical',
        top: '28%',
        right: '20%',
        data: ['基础能力测评', '进阶能力测评', '专项能力测评'],
        textStyle: {
          fontSize: 14
        },
        icon: 'circle',
        itemGap: 15
      },
      color: ['#2d3446', '#61a0a8', '#c23531'],
      series: [
        {
          name: '监测测评次数',
          type: 'pie',
          radius: '60%',
          center: ['20%', '50%'],
          label: {
            normal: {
              show: false
            },
            emphasis: {
              show: false
            }
          },
          data: [
            {value: '', name: '基础能力测评'},
            {value: '', name: '进阶能力测评'},
            {value: '', name: '专项能力测评'}
          ]
        }
      ]
    },
    BASE_TEST: {
      legend: {
        data: ['平均跑动距离', '平均高强度跑距离', '平均心率', {name: '全国平均跑动距离', icon: 'line'}]
        // selected: {
        //   '场均高于平均心率人数占比': false
        // }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      barGap: '1%',
      color: ['#2d3446', '#61a0a8', '#d48265', '#2d3446'],
      grid: {
        left: '4%',
        right: '5%',
        bottom: '22%'
      },
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          rotate: 45,
          interval: 0
        }
      },
      yAxis: [
        {
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        },
        {
          min: 0,
          // max: 100,
          name: '心率(bpm)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '平均跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: []
          // markLine: {
          //   data: [
          //     {type: 'average', name: '平均值'}
          //   ],
          //   label: {
          //     normal: {
          //       show: false
          //     }
          //   }
          // }
        },
        {
          name: '平均高强度跑距离',
          type: 'bar',
          barMaxWidth: 40,
          data: []
        },
        {
          name: '平均心率',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: []
        },
        {
          name: '全国平均跑动距离',
          type: 'line',
          data: [],
          markLine: {
            data: [
              {
                yAxis: 110
                // name: '全国平均'
              }
            ],
            label: {
              normal: {
                show: false
              }
            }
          }
        }
      ]
    },
    ADVANCE_TEST: {
      legend: {
        data: ['平均跑动距离', '平均高强度跑距离', '平均心率', {name: '全国平均跑动距离', icon: 'line'}],
        selected: {
          '平均心率': true
          // '变向次数': false
        }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      barGap: '1%',
      color: ['#61a0a8', '#c23531', '#d48265', '#96ce57', '#61a0a8'],
      grid: {
        left: '4%',
        right: '5%',
        bottom: '22%'
      },
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          rotate: 45,
          interval: 0
        }
      },
      yAxis: [
        {
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        },
        {
          min: 0,
          // max: 100,
          name: '心率(bpm)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '平均跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: []
        },
        {
          name: '平均高强度跑距离',
          type: 'bar',
          barMaxWidth: 40,
          data: []
        },
        {
          name: '平均心率',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: []
        },
        // {
        //   name: '变向次数',
        //   type: 'line',
        //   symbolSize: 8,
        //   yAxisIndex: 1,
        //   data: []
        // },
        {
          name: '全国平均跑动距离',
          type: 'line',
          data: [],
          markLine: {
            data: [
              {
                yAxis: 240
                // name: '全国平均'
              }
            ],
            label: {
              normal: {
                show: false
              }
            }
          }
        }
      ]
    },
    YOYO_TEST: {
      legend: {
        data: ['平均跑动距离', '平均心率', {name: '全国平均跑动距离', icon: 'line'}]
        // selected: {
        //   '场均高于平均心率人数占比': false
        // }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#61a0a8', '#c23531', '#61a0a8'],
      grid: {
        left: '4%',
        right: '5%',
        bottom: '22%'
      },
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          rotate: 45,
          interval: 0
        }
      },
      yAxis: [
        {
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        },
        {
          min: 0,
          // max: 100,
          name: '心率(bpm)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '平均跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: []
          // markLine: {
          //   data: [
          //     {type: 'average', name: '平均值'}
          //   ],
          //   label: {
          //     normal: {
          //       show: false
          //     }
          //   }
          // }
        },
        {
          name: '平均心率',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: []
        },
        {
          name: '全国平均跑动距离',
          type: 'line',
          data: [],
          markLine: {
            data: [
              {
                yAxis: 900
                // name: '全国平均'
              }
            ],
            label: {
              normal: {
                show: false
              }
            }
          }
        }
      ]
    },
    SIX_YOYO_TEST: {
      legend: {
        data: ['平均跑动距离', '平均心率', '平均心率恢复指数', {name: '全国平均跑动距离', icon: 'line'}],
        selected: {
          '平均心率': true,
          '平均心率恢复指数': false
        }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#61a0a8', '#c23531', '#96ce57', '#61a0a8'],
      grid: {
        left: '4%',
        right: '5%',
        bottom: '22%'
      },
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          rotate: 45,
          interval: 0
        }
      },
      yAxis: [
        {
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        },
        {
          min: 0,
          // max: 100,
          name: '心率(bpm)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '平均跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: []
          // markLine: {
          //   data: [
          //     {type: 'average', name: '平均值'}
          //   ],
          //   label: {
          //     normal: {
          //       show: false
          //     }
          //   }
          // }
        },
        {
          name: '平均心率',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: []
        },
        {
          name: '平均心率恢复指数',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: []
        },
        {
          name: '全国平均跑动距离',
          type: 'line',
          data: [],
          markLine: {
            data: [
              {
                yAxis: 630
                // name: '全国平均'
              }
            ],
            label: {
              normal: {
                show: false
              }
            }
          }
        }
      ]
    },
    PERSON_COUNT: {
      legend: {
        data: []
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#2f4554', '#619fa7', '#91c7ae'],
      grid: {
        left: '4%',
        right: '5%',
        bottom: '22%'
      },
      xAxis: {
        type: 'category',
        axisLabel: {
          rotate: 45,
          interval: 0
        },
        data: ['北京市', '河南省', '广州']
      },
      yAxis: [
        {
          min: 0,
          name: '人数',
          splitLine: {
            show: false
          }
        }
      ],
      series: []
    },
    TIMES_ECHARTS: {
      legend: {
        data: ['基础能力测评', '进阶能力测评', '专项能力测评']
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#2f4554', '#619fa7', '#91c7ae'],
      grid: {
        left: '4%',
        right: '5%',
        bottom: '22%'
      },
      xAxis: {
        type: 'category',
        axisLabel: {
          rotate: 45,
          interval: 0
        },
        data: ['北京市', '河南省', '广州']
      },
      yAxis: [
        {
          min: 0,
          name: '次数',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '基础能力测评',
          type: 'bar',
          barMaxWidth: 40,
          stack: '人数',
          data: [200, 150, 180]
        },
        {
          name: '进阶能力测评',
          type: 'bar',
          barMaxWidth: 40,
          stack: '人数',
          data: [200, 150, 180]
        },
        {
          name: '专项能力测评',
          type: 'bar',
          barMaxWidth: 40,
          stack: '人数',
          data: [200, 150, 180]
        }
      ]
    }
  },
  // 专项测评概览结束
  TEST_COMPARE: {
    BASE_COMPARE: {
      legend: {
        data: ['跑动距离', '高强度跑距离', '平均心率', '最高心率']
      },
      grid: {
        left: '4%',
        right: '5%',
        bottom: '22%'
      },
      tooltip: {},
      color: ['#91c7ae', '#5889b1', '#ff9b9b', '#CA8622', '#BDA29A'],
      textStyle: {fontSize: 14},
      barGap: '3%',
      xAxis: {
        type: 'category',
        data: ['队伍1', '队伍2', '队伍3', '队伍4', '队伍5'],
        splitLine: {show: false},
        axisLabel: {
          rotate: 45,
          interval: 0
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '距离(m)',
          splitLine: {show: false},
          nameTextStyle: {
            color: '#000',
            fontSize: 12
          }
        },
        {
          type: 'value',
          min: 0,
          name: '心率(bpm)',
          splitLine: {show: false},
          nameTextStyle: {
            color: '#000',
            fontSize: 12
          }
        }
      ],
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          barWidth: 60,
          data: []
        },
        {
          name: '高强度跑距离',
          type: 'bar',
          barWidth: 60,
          data: []
        },
        {
          name: '平均心率',
          type: 'line',
          yAxisIndex: 1,
          symbolSize: 8,
          data: []
        },
        {
          name: '最高心率',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: []
        }
      ]
    },
    ADVANCE_COMPARE: {
      legend: {
        data: ['跑动距离', '高强度跑距离', '最高心率', '变向次数', '阵型覆盖面积'],
        selected: {
          '最高心率': true,
          '变向次数': false,
          '阵型覆盖面积': false
        }
      },
      grid: {
        left: '4%',
        right: '5%',
        bottom: '22%'
      },
      tooltip: {},
      color: ['#91c7ae', '#5889b1', '#ff9b9b', '#CA8622', '#BDA29A'],
      textStyle: {fontSize: 14},
      barGap: '3%',
      xAxis: {
        type: 'category',
        data: ['队伍1', '队伍2', '队伍3', '队伍4', '队伍5'],
        splitLine: {show: false},
        axisLabel: {
          rotate: 45,
          interval: 0
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '距离(m)',
          splitLine: {show: false},
          nameTextStyle: {
            color: '#000',
            fontSize: 12
          }
        },
        {
          type: 'value',
          min: 0,
          name: '心率(bpm)',
          splitLine: {show: false},
          nameTextStyle: {
            color: '#000',
            fontSize: 12
          }
        }
      ],
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          barWidth: 60,
          data: []
        },
        {
          name: '高强度跑距离',
          type: 'bar',
          barWidth: 60,
          data: []
        },
        {
          name: '最高心率',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: []
        },
        {
          name: '变向次数',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: []
        },
        {
          name: '阵型覆盖面积',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: []
        }
      ]
    },
    SPECIAL_COMPARE: {
      legend: {
        data: ['跑动距离', '心率恢复指数', '平均心率', '最高心率'],
        selected: {
          '跑动距离': true,
          '心率恢复指数': false
        }
      },
      grid: {
        left: '4%',
        right: '5%',
        bottom: '22%'
      },
      tooltip: {},
      color: ['#91c7ae', '#5889b1', '#ff9b9b', '#CA8622', '#BDA29A'],
      textStyle: {fontSize: 14},
      barGap: '3%',
      xAxis: {
        type: 'category',
        data: ['队伍1', '队伍2', '队伍3', '队伍4', '队伍5'],
        splitLine: {show: false},
        axisLabel: {
          rotate: 45,
          interval: 0
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '距离(m)',
          splitLine: {show: false},
          nameTextStyle: {
            color: '#000',
            fontSize: 12
          }
        },
        {
          type: 'value',
          min: 0,
          name: '心率(bpm)',
          splitLine: {show: false},
          nameTextStyle: {
            color: '#000',
            fontSize: 12
          }
        }
      ],
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          barWidth: 60,
          data: []
        },
        {
          name: '心率恢复指数',
          type: 'bar',
          barWidth: 60,
          data: []
        },
        {
          name: '平均心率',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: []
        },
        {
          name: '最高心率',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: []
        }
      ]
    }
  },
  TEST_RANK: {
    total_distance: {name: '平均距离(m)', sort: true, type: 'total_distance'},
    sum_speed56: {name: '高速跑距离(m)', sort: true, type: 'sum_speed56'},
    heart_rate_max: {name: '最高心率(bpm)', sort: true, type: 'heart_rate_max'},
    heart_rate_avg: {name: '平均心率(bpm)', sort: true, type: 'heart_rate_avg'},
    turning_times: {name: '变向次数', sort: true, type: 'turning_times'},
    formation_area: {name: '阵型覆盖面积', sort: true, type: 'formation_area '},
    heart_rate_last: {name: '测评结束即刻心率', sort: true, type: 'heart_rate_last'},
    heart_rate_recovery: {name: '心率恢复指数', sort: true, type: 'heart_rate_recovery'}
  }
}

export default TEST
