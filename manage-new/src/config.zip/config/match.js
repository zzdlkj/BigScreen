/**
 * Created by dongshuyue on 2016/10/25.
 */
const MATCH = {
  TAB_HEADER_TEAM_AVG: [
    {name: '队伍', sort: false, type: 'team_name'},
    {name: '赛制', sort: false, type: 'count'},
    {name: '平均距离(m)', sort: true, type: 'total_distance'},
    {name: '场数', sort: true, type: 'count'},
    {name: '平均心率(bpm)', sort: true, type: 'heart_rate_avg'},
    {name: '平均负荷(trimp)', sort: true, type: 'bpm'}
  ],
  TAB_LIST_TEAM_AVG: ['team_name', 'formation_cnt', 'total_distance', 'count', 'heart_rate_avg', 'bpm'],
  TAB_HEADER_TEAM_SINGLE: [
    {name: '队伍', sort: false, type: 'team_name1'},
    {name: '比分', sort: false, type: 'score'},
    {name: '对手', sort: false, type: 'team_name2'},
    {name: '赛制', sort: false, type: 'count'},
    {name: '平均距离(m)', sort: true, type: 'total_distance'},
    {name: '平均心率(bpm)', sort: true, type: 'heart_rate_avg'},
    {name: '平均负荷(trimp)', sort: true, type: 'bpm'},
    {name: '时间', sort: true, type: 'match_start_time'}
  ],
  TAB_LIST_TEAM_SINGLE: ['red_team_name', 'score', 'blue_team_name', 'formation_cnt', 'total_distance', 'heart_rate_avg', 'bpm', 'match_start_time'],
  TAB_HEADER_PERSON_AVG: [
    {name: '人员', sort: false, type: 'person_name'},
    {name: '队伍', sort: false, type: 'team_name'},
    {name: '赛制', sort: false, type: 'formation_cnt'},
    {name: '场数', sort: false, type: 'count'},
    {name: '场均距离(m)', sort: true, type: 'high_speed_distance'},
    {name: '平均心率(bpm)', sort: true, type: 'heart_rate_avg'},
    {name: '场均负荷(trimp)', sort: true, type: 'bpm'}
  ],
  TAB_LIST_PERSON_AVG: ['person_name', '', 'formation_cnt', 'count', 'high_speed_distance', 'heart_rate_avg', 'bpm'],
  TAB_HEADER_PERSON_SINGLE: [
    {name: '人员', sort: false, type: 'person_name'},
    {name: '队伍', sort: false, type: 'red_team_name'},
    {name: '对阵', sort: false, type: 'blue_team_name'},
    {name: '上场时长', sort: false, type: 'during_time'},
    {name: '赛制', sort: false, type: 'formation_cnt'},
    {name: '距离', sort: false, type: 'total_distance'},
    {name: '平均心率', sort: true, type: 'heart_rate_avg'},
    {name: '负荷', sort: true, type: 'bpm'},
    {name: '比赛时间', sort: false, type: 'start_time'}
  ],
  TAB_LIST_PERSON_SINGLE: ['person_name', 'red_team_name', 'blue_team_name', 'during_time', 'formation_cnt', 'total_distance', 'heart_rate_avg', 'bpm', 'start_time'],
  MATCH_PERSON_REPORT: {
    HR_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        formatter: function (params) {
          let str = params[0].name
          params.forEach(function (val) {
            str += '<br>' + val.seriesName + ' : ' + val.value + '%'
          })
          return str
        }
      },
      grid: {
        left: '0%',
        right: '0%',
        bottom: '3%',
        containLabel: true
      },
      legend: {
        data: ['', '队伍平均', '个人历史平均', '全国平均'],
        top: '3%'
      },
      color: ['#9fd367', '#ce6763', '#6593b7', '#3f4658'],
      xAxis: {
        type: 'category',
        data: ['[0-65%]', '[66%-71%]', '[72%-78%]', '[79%-85%]', '[86%-92%]', '[93%-100%]'].map(function (str) {
          return str.replace(' ', '\n\n')
        }),
        splitArea: {
          show: true,
          areaStyle: {
            color: ['#b2e0d1', '#fff5c1', '#ffe0c1', '#f0b7c5', '#d1b2e0', '#d8b2bd']
          }
        }
      },
      yAxis: [
        {
          type: 'value',
          max: 100,
          min: 0,
          splitLine: {
            show: false
          },
          axisLabel: {
            formatter: '{value}%'
          }
        }
      ],
      series: [
        {
          name: '',
          type: 'bar',
          barMaxWidth: 40,
          data: []
        },
        {
          name: '队伍平均',
          type: 'line',
          symbolSize: 8,
          barMaxWidth: 40,
          data: []
        },
        {
          name: '个人历史平均',
          type: 'line',
          symbolSize: 8,
          data: []
        },
        {
          name: '全国平均',
          type: 'line',
          symbolSize: 8,
          data: []
        }
      ]
    },
    SP_ECHARTS: {
      grid: {
        left: '0%',
        right: '0%',
        bottom: '3%',
        containLabel: true
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        formatter: function (params) {
          let str = params[0].name
          params.forEach(function (val) {
            str += '<br>' + val.seriesName + ' : ' + val.value + '%'
          })
          return str
        }
      },
      legend: {
        data: ['', '队伍平均', '个人历史平均', '全国平均'],
        top: '3%'
      },
      color: ['#9fd367', '#ce6763', '#6593b7', '#3f4658'],
      xAxis: {
        type: 'category',
        data: ['走慢跑 [0-1.6)', '低速跑 [1.6-2.5)', '中速跑 [2.5-3.5)', '快速跑 [3.5-4.5)', '高速跑 [4.5-5.3)', '冲刺跑 [5.3)'].map(function (str) {
          return str.replace(' ', '\n')
        }),
        splitArea: {
          show: true,
          areaStyle: {
            color: ['#b2e0d1', '#fff5c1', '#ffe0c1', '#f0b7c5', '#d1b2e0', '#d8b2bd']
          }
        }
      },
      yAxis: [
        {
          type: 'value',
          max: 100,
          min: 0,
          splitLine: {
            show: false
          },
          axisLabel: {
            formatter: '{value}%'
          }
        }
      ],
      series: [
        {
          name: '',
          type: 'bar',
          barMaxWidth: 40,
          data: []
        },
        {
          name: '队伍平均',
          type: 'line',
          symbolSize: 8,
          data: []
        },
        {
          name: '个人历史平均',
          type: 'line',
          symbolSize: 8,
          data: []
        },
        {
          name: '全国平均',
          type: 'line',
          symbolSize: 8,
          data: []
        }
      ]
    },
    LOAD_ECHARTS: {
      tooltip: {},
      legend: {
        data: ['', '队伍平均', '个人历史平均', '全国平均'],
        top: '3%'
      },
      color: ['#9fd367', '#ce6763', '#6593b7', '#3f4658'],
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          interval: 0
        },
        boundaryGap: false
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '负荷',
          splitLine: {
            show: true
          }
        }
      ],
      series: [
        {
          name: '',
          type: 'line',
          symbolSize: 8,
          data: []
        },
        {
          name: '队伍平均',
          type: 'line',
          symbolSize: 8,
          data: [],
          markLine: {
            lineStyle: {
              normal: {
                type: 'dashed'
              }
            },
            data: [
              {type: 'average'}
            ]
          }
        },
        {
          name: '个人历史平均',
          type: 'line',
          symbolSize: 8,
          data: [],
          markLine: {
            lineStyle: {
              normal: {
                type: 'dashed'
              }
            },
            data: [
              {type: 'average'}
            ]
          }
        },
        {
          name: '全国平均',
          type: 'line',
          symbolSize: 8,
          data: [],
          markLine: {
            lineStyle: {
              normal: {
                type: 'dashed'
              }
            },
            data: [
              {type: 'average'}
            ]
          }
        }
      ]
    },
    PHYSICAL_LOAD: {
      tooltip: {},
      legend: {
        data: ['', '队伍平均', '个人历史平均', '全国平均'],
        top: '3%'
      },
      color: ['#9fd367', '#ce6763', '#6593b7', '#3f4658'],
      xAxis: {
        type: 'category',
        data: [],
        boundaryGap: false,
        axisLabel: {
          interval: 0
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '负荷',
          splitLine: {
            show: true
          }
        }
      ],
      series: [
        {
          name: '',
          type: 'line',
          symbolSize: 8,
          data: []
        },
        {
          name: '队伍平均',
          type: 'line',
          symbolSize: 8,
          data: [],
          markLine: {
            lineStyle: {
              normal: {
                type: 'dashed'
              }
            },
            data: [
              {type: 'average'}
            ]
          }
        },
        {
          name: '个人历史平均',
          type: 'line',
          symbolSize: 8,
          data: [],
          markLine: {
            lineStyle: {
              normal: {
                type: 'dashed'
              }
            },
            data: [
              {type: 'average'}
            ]
          }
        },
        {
          name: '全国平均',
          type: 'line',
          symbolSize: 8,
          data: [],
          markLine: {
            lineStyle: {
              normal: {
                type: 'dashed'
              }
            },
            data: [
              {type: 'average'}
            ]
          }
        }
      ]
    }
  },
  MATCH_TEAM_REPORT: {
    HR_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        formatter: function (params) {
          let str = params[0].name
          params.forEach(function (val) {
            str += '<br>' + val.seriesName + ' : ' + val.value + '%'
          })
          return str
        }
      },
      grid: {
        left: '0%',
        right: '0%',
        bottom: '4%',
        containLabel: true
      },
      legend: {
        data: [],
        top: '3%'
      },
      color: ['#e93232', '#61a0a8', '#d48265', '#2f4554', '#eed766'],
      xAxis: {
        type: 'category',
        data: ['[0-65%]', '[66%-71%]', '[72%-78%]', '[79%-85%]', '[86%-92%]', '[93%-100%]'].map(function (str) {
          return str.replace(' ', '\n\n')
        }),
        splitArea: {
          show: true,
          areaStyle: {
            color: ['#b2e0d1', '#fff5c1', '#ffe0c1', '#f0b7c5', '#d1b2e0', '#d8b2bd']
          }
        },
        axisLabel: {
          interval: 0
        }
      },
      yAxis: [
        {
          type: 'value',
          max: 100,
          min: 0,
          name: '占比',
          splitLine: {
            show: false
          },
          axisLabel: {
            formatter: '{value}%'
          }
        }
      ],
      series: []
    },
    SP_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        formatter: function (params) {
          let str = params[0].name
          params.forEach(function (val) {
            str += '<br>' + val.seriesName + ' : ' + val.value + '%'
          })
          return str
        }
      },
      grid: {
        left: '0%',
        right: '0%',
        bottom: '0%',
        containLabel: true
      },
      legend: {
        data: [],
        top: '3%'
      },
      color: ['#e93232', '#61a0a8', '#d48265', '#2f4554', '#eed766'],
      xAxis: {
        type: 'category',
        data: ['走慢跑 [0-1.6)', '低速跑 [1.6-2.5)', '中速跑 [2.5-3.5)', '快速跑 [3.5-4.5)', '高速跑 [4.5-5.3)', '冲刺跑 [5.3)'].map(function (str) {
          return str.replace(' ', '\n')
        }),
        splitArea: {
          show: true,
          areaStyle: {
            color: ['#b2e0d1', '#fff5c1', '#ffe0c1', '#f0b7c5', '#d1b2e0', '#d8b2bd']
          }
        },
        axisLabel: {
          interval: 0
        }
      },
      yAxis: [
        {
          type: 'value',
          max: 100,
          min: 0,
          name: '占比',
          splitLine: {
            show: false
          },
          axisLabel: {
            formatter: '{value} %'
          }
        }
      ],
      series: []
    },
    LOAD_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: [],
        top: '3%'
      },
      grid: {
        left: '5%',
        right: '5%',
        bottom: '3%',
        containLabel: true
      },
      color: ['#e93232', '#61a0a8', '#d48265'],
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          interval: 0
        },
        boundaryGap: false
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: 'trimp',
          splitLine: {
            show: false
          }
        }
      ],
      series: []
    },
    PHYSICAL_LOAD: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      grid: {
        left: '5%',
        right: '5%',
        bottom: '3%',
        containLabel: true
      },
      legend: {
        data: [],
        top: '3%'
      },
      color: ['#e93232', '#61a0a8', '#d48265'],
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          interval: 0
        },
        boundaryGap: false
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '负荷',
          splitLine: {
            show: false
          }
        }
      ],
      series: []
    },
    SPRINT_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['冲刺距离', '冲刺跑占比'],
        top: '3%'
      },
      grid: {
        left: '5%',
        right: '5%',
        bottom: '27%'
      },
      color: ['#d48265', '#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          interval: 0,
          rotate: 45
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        },
        {
          type: 'value',
          min: 0,
          max: 100,
          name: '占比(%)',
          axisLabel: {
            formatter: '{value} %'
          },
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '冲刺距离',
          type: 'bar',
          barMaxWidth: '40',
          data: []
        },
        {
          name: '冲刺跑占比',
          type: 'line',
          symbolSize: 8,
          data: [],
          yAxisIndex: 1
        }
      ]
    },
    GQD_RHY_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: [],
        top: '3%'
      },
      grid: {
        left: '5%',
        right: '5%'
      },
      color: ['#e93232', '#61a0a8', '#d48265'],
      xAxis: {
        type: 'category',
        data: [],
        boundaryGap: false
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        }
      ],
      series: []
    },
    DISTANCE_ECHARTS: {
      legend: {
        data: ['跑动距离'],
        top: '3%'
      },
      grid: {
        left: '5%',
        right: '5%',
        bottom: '27%'
      },
      color: ['#61a0a8', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '跑动距离',
          type: 'bar',
          barMaxWidth: '40',
          data: []
        }
      ]
    },
    HIGH_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['高速跑距离', '高速跑占比'],
        top: '3%'
      },
      grid: {
        left: '5%',
        right: '5%',
        bottom: '27%'
      },
      color: ['#2f4554', '#e93232', '#d48265'],
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          interval: 0,
          rotate: 45
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        },
        {
          type: 'value',
          min: 0,
          max: 100,
          name: '占比(%)',
          axisLabel: {
            formatter: '{value} %'
          },
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '高速跑距离',
          type: 'bar',
          barMaxWidth: '40',
          data: [],
          markLine: {
            data: [
              {
                yAxis: 1100,
                name: '全国平均值'
              }
            ]
          }
        },
        {
          name: '高速跑占比',
          type: 'line',
          symbolSize: 8,
          data: [],
          yAxisIndex: 1
        }
      ]
    },
    SP_ADVANCE_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        formatter: function (params) {
          let str = params[0].name
          params.forEach(function (val) {
            str += '<br>' + val.seriesName + ' : ' + val.value + '%'
          })
          return str
        }
      },
      legend: {
        data: ['走慢跑 [0-1.6)', '低速跑 [1.6-2.5)', '中速跑 [2.5-3.5)', '快速跑 [3.5-4.5)', '高速跑 [4.5-5.3)', '冲刺跑 [5.3)'],
        top: '3%'
      },
      grid: {
        left: '5%',
        right: '5%'
      },
      color: ['#82cd71', '#add857', '#eed766', '#ec9e51', '#f06044', '#ce0f3f'],
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          interval: 0,
          rotate: 45
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          max: 100,
          name: '占比',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '走慢跑 [0-1.6)',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: '40',
          data: []
        },
        {
          name: '低速跑 [1.6-2.5)',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: '40',
          data: []
        },
        {
          name: '中速跑 [2.5-3.5)',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: '40',
          data: []
        },
        {
          name: '快速跑 [3.5-4.5)',
          stack: '个人数据',
          barMaxWidth: '40',
          type: 'bar',
          data: []
        },
        {
          name: '高速跑 [4.5-5.3)',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: '40',
          data: []
        },
        {
          name: '冲刺跑 [5.3)',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: '40',
          data: []
        }
      ]
    },
    HR_ADVANCE_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        },
        formatter: function (params) {
          let str = params[0].name
          params.forEach(function (val) {
            str += '<br>' + val.seriesName + ' : ' + val.value + '%'
          })
          return str
        }
      },
      legend: {
        data: ['[0-65%]', '[66%-71%]', '[72%-78%]', '[79%-85%]', '[86%-92%]', '[93%-100%]'],
        top: '3%'
      },
      grid: {
        left: '5%',
        right: '5%'
      },
      color: ['#82cd71', '#add857', '#eed766', '#ec9e51', '#f06044', '#ce0f3f'],
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          interval: 0,
          rotate: 45
          // 设置成0 之后就会强制显示文字 因为默认 会将重叠部分去掉
          // 旋转坐标轴文字 rotate: 60
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          max: 100,
          name: '占比',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '[0-65%]',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: '40',
          data: []
        },
        {
          name: '[66%-71%]',
          stack: '个人数据',
          barMaxWidth: '40',
          type: 'bar',
          data: []
        },
        {
          name: '[72%-78%]',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: '40',
          data: []
        },
        {
          name: '[79%-85%]',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: '40',
          data: []
        },
        {
          name: '[86%-92%]',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: '40',
          data: []
        },
        {
          name: '[93%-100%]',
          stack: '个人数据',
          type: 'bar',
          barMaxWidth: '40',
          data: []
        }
      ]
    },
    LOAD_ADVANCE_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      legend: {
        data: ['心率负荷', '身体负荷'],
        top: '3%'
      },
      grid: {
        left: '5%',
        right: '5%',
        bottom: '25%'
      },
      color: ['#e93232', '#61a0a8', '#d48265'],
      xAxis: {
        type: 'category',
        data: [],
        axisLabel: {
          interval: 0,
          rotate: 45
          // 设置成0 之后就会强制显示文字 因为默认 会将重叠部分去掉
          // 旋转坐标轴文字 rotate: 60
        }
      },
      yAxis: [
        {
          type: 'value',
          min: 0,
          name: '负荷',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '心率负荷',
          type: 'line',
          symbolSize: 8,
          data: []
        },
        {
          name: '身体负荷',
          type: 'line',
          symbolSize: 8,
          data: []
        }
        // {
        //   name: '跑动指数',
        //   type: 'line',
        //   symbolSize: 8,
        //   data: [],
        //   yAxisIndex: 1
        // }
      ]
    }
  },
  TOOLTIP: {
    trigger: 'axis',
    axisPointer: {
      type: 'shadow'
    },
    formatter: function (params) {
      let str = params[0].name
      params.forEach(function (val) {
        str += '<br>' + val.seriesName + ' : ' + val.value + '%'
      })
      return str
    }
  },
  MATCH_VIEW: {
    VIEW_ECHARTS: {
      legend: {
        data: ['场均跑动距离', '场均高强度跑距离占比', '高于平均心率人数占比']
        // selected: {
        //   '场均高于平均心率人数占比': false
        // }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
        // formatter: function (val) {

        //   var value = val[0].color + val[0].seriesName + ' : ' + val[0].value + '<br/>' + val[1].color + val[1].seriesName + ' : ' + val[1].value + '<br/>' + val[2].color + val[2].seriesName + ' : ' + val[2].value
        //   return value
        // }
      },
      color: ['#61a0a8', '#c23531', '#96ce57'],
      grid: {
        left: '6%',
        right: '5%',
        bottom: '22%'
      },
      xAxis: {
        type: 'category',
        axisLabel: {
          rotate: 45,
          interval: 0,
          formatter: function (params) {
            if (!params) return ''
            var newParamsName = ''
            var paramsNameNumber = params.length
            var provideNumber = 8
            var rowNumber = Math.ceil(paramsNameNumber / provideNumber)
            if (paramsNameNumber > provideNumber) {
              for (var p = 0; p < rowNumber; p++) {
                var tempStr = ''
                var start = p * provideNumber
                var end = start + provideNumber
                if (p === rowNumber - 1) {
                  tempStr = params.substring(start, paramsNameNumber)
                } else {
                  tempStr = params.substring(start, end) + '\n'
                }
                newParamsName += tempStr
              }
            } else {
              newParamsName = params
            }
            return newParamsName
          }
        },
        data: []
      },
      yAxis: [
        {
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        },
        {
          min: 0,
          max: 100,
          name: '占比(%)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '场均跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: [],
          markLine: {
            data: [
              {type: 'average', name: '平均值'}
            ],
            label: {
              normal: {
                show: false
              }
            }
          }
        },
        {
          name: '场均高强度跑距离占比',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: []
        },
        {
          name: '高于平均心率人数占比',
          type: 'line',
          symbolSize: 8,
          yAxisIndex: 1,
          data: []
        }
        // {
        //   name: '全国最高',
        //   type: 'line',
        //   symbolSize: 8,
        //   yAxisIndex: 0,
        //   data: [],
        //   markLine: {
        //     data: [
        //       {
        //         name: '全国最高',
        //         yAxis: 47801,
        //         lineStyle: {
        //           normal: {
        //             color: '#D48265'
        //           }
        //         }
        //       }
        //     ],
        //     label: {
        //       normal: {
        //         formatter: '{c} m'
        //       }
        //     }
        //     // lineStyle: {
        //     //   normal: {
        //     //     color: '#D48265'
        //     //   }
        //     // }
        //   }
        // }
      ]
    },
    TREND_ECHARTS: {
      legend: {
        data: ['场均跑动距离', '场均高强度跑距离占比', '高于平均心率人数占比']
        // selected: {
        //   '场均高于平均心率人数占比': false
        // }
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#61a0a8', '#c23531', '#96ce57'],
      grid: {
        left: '6%',
        right: '5%',
        bottom: '22%'
      },
      xAxis: {
        type: 'category',
        axisLabel: {
          rotate: 45,
          interval: 0,
          formatter: function (params) {
            if (!params) return ''
            var newParamsName = ''
            var paramsNameNumber = params.length
            var provideNumber = 8
            var rowNumber = Math.ceil(paramsNameNumber / provideNumber)
            if (paramsNameNumber > provideNumber) {
              for (var p = 0; p < rowNumber; p++) {
                var tempStr = ''
                var start = p * provideNumber
                var end = start + provideNumber
                if (p === rowNumber - 1) {
                  tempStr = params.substring(start, paramsNameNumber)
                } else {
                  tempStr = params.substring(start, end) + '\n'
                }
                newParamsName += tempStr
              }
            } else {
              newParamsName = params
            }
            return newParamsName
          }
        },
        data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
      },
      yAxis: [
        {
          min: 0,
          name: '距离(m)',
          splitLine: {
            show: false
          }
        },
        {
          min: 0,
          max: 100,
          name: '占比(%)',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '场均跑动距离',
          type: 'bar',
          barMaxWidth: 40,
          data: ['500', '600', '700', '500', '600', '700', '500', '600', '900', '500', '600', '700'],
          markLine: {
            data: [
              {type: 'average', name: '平均值'}
            ],
            label: {
              normal: {
                show: false
              }
            }
          }
        },
        {
          name: '场均高强度跑距离占比',
          type: 'line',
          yAxisIndex: 1,
          symbolSize: 8,
          data: ['80', '60', '40', '60', '80', '60', '40', '60', '80', '60', '40', '60']
        },
        {
          name: '高于平均心率人数占比',
          type: 'line',
          yAxisIndex: 1,
          symbolSize: 8,
          data: ['60', '80', '50', '70', '60', '80', '50', '70', '60', '80', '50', '70']
        }
        // {
        //   name: '全国最高',
        //   type: 'line',
        //   symbolSize: 8,
        //   yAxisIndex: 0,
        //   data: [],
        //   markLine: {
        //     data: [
        //       {
        //         name: '全国最高',
        //         yAxis: 47801,
        //         lineStyle: {
        //           normal: {
        //             color: '#D48265'
        //           }
        //         }
        //       }
        //     ],
        //     label: {
        //       normal: {
        //         formatter: '{c} m'
        //       }
        //     }
        //     // lineStyle: {
        //     //   normal: {
        //     //     color: '#D48265'
        //     //   }
        //     // }
        //   }
        // },
        // {
        //   name: '全国平均',
        //   type: 'line',
        //   symbolSize: 8,
        //   yAxisIndex: 0,
        //   data: [],
        //   markLine: {
        //     data: [
        //       {
        //         name: '全国平均',
        //         yAxis: 26801,
        //         lineStyle: {
        //           normal: {
        //             color: '#91C7AE'
        //           }
        //         }
        //       }
        //     ],
        //     label: {
        //       normal: {
        //         formatter: '{c} m'
        //       }
        //     }
        //     // lineStyle: {
        //     //   normal: {
        //     //     color: '#D48265'
        //     //   }
        //     // }
        //   }
        // }
      ]
    },
    MINTOR_ECHARTS: {
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      grid: {
        left: '10%',
        right: '4%',
        top: '17%',
        bottom: '15%'
      },
      xAxis: {
        type: 'category',
        data: [],
        splitLine: {
          show: false
        }
      },
      color: ['#2f4554'],
      yAxis: [
        {
          type: 'value',
          name: '人数',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '监测人数',
          type: 'bar',
          bbarMaxWidth: 40,
          label: {
            normal: {
              show: true,
              position: 'top'
            }
          },
          data: []
        }
      ]
    },
    MATCH_TOTAL_ECHART: {
      tooltip: {
        formatter: '{a0}<br>{b0}'
      },
      legend: {
        orient: 'vertical',
        top: '15%',
        right: '26%',
        data: []
      },
      color: ['#91c7ae', '#d48265', '#61a0a8', '#c23531', '#2d3446'],
      series: [
        {
          name: '监测比赛场次',
          type: 'pie',
          radius: '60%',
          center: ['15%', '45%'],
          label: {
            normal: {
              show: false
            },
            emphasis: {
              show: false
            }
          },
          data: []
        }
      ]
    },
    PERSON_COUNT: {
      legend: {
        data: ['男', '女']
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      color: ['#2f4554', '#c23531', '#619fa7', '#91c7ae'],
      grid: {
        left: '4%',
        right: '5%',
        bottom: '20%'
      },
      xAxis: {
        type: 'category',
        axisLabel: {
          rotate: 45,
          interval: 0
        },
        data: []
      },
      yAxis: [
        {
          min: 0,
          name: '人数',
          splitLine: {
            show: false
          }
        }
      ],
      series: [
        {
          name: '男',
          type: 'bar',
          barMaxWidth: 40,
          stack: '人数',
          data: []
        },
        {
          name: '女',
          type: 'bar',
          barMaxWidth: 40,
          stack: '人数',
          data: []
        }
      ]
    },
    TIMES_ECHARTS: {
      legend: {
        data: ['省级', '市级', '区级', '校级', '其他']
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: {
          type: 'shadow'
        }
      },
      // color: ['#2f4554', '#619fa7', '#91c7ae'],
      grid: {
        left: '4%',
        right: '5%',
        bottom: '22%'
      },
      xAxis: {
        type: 'category',
        axisLabel: {
          rotate: 45,
          interval: 0
        },
        data: []
      },
      yAxis: {
        min: 0,
        name: '人数',
        splitLine: {
          show: false
        }
      },
      series: [
        {
          name: '省级',
          type: 'bar',
          barMaxWidth: 40,
          stack: '人数',
          data: []
        },
        {
          name: '市级',
          type: 'bar',
          barMaxWidth: 40,
          stack: '人数',
          data: []
        },
        {
          name: '区级',
          type: 'bar',
          barMaxWidth: 40,
          stack: '人数',
          data: []
        },
        {
          name: '校级',
          type: 'bar',
          barMaxWidth: 40,
          stack: '人数',
          data: []
        },
        {
          name: '其他',
          type: 'bar',
          barMaxWidth: 40,
          stack: '人数',
          data: []
        }
      ]
    }
  }
}
export default MATCH
